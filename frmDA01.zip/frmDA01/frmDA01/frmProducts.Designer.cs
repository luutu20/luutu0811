﻿namespace frmDA01
{
    partial class frmProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProducts));
            this.btnSearch = new System.Windows.Forms.Button();
            this.dgvProducts = new System.Windows.Forms.DataGridView();
            this.ProductID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CategoryName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TradeMarkName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductMaterials = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Color = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Size = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MadeIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbTradeMarkName = new System.Windows.Forms.RadioButton();
            this.rbProductName = new System.Windows.Forms.RadioButton();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.lbDescription = new System.Windows.Forms.Label();
            this.lbSize = new System.Windows.Forms.Label();
            this.lbColor = new System.Windows.Forms.Label();
            this.lbMadeIn = new System.Windows.Forms.Label();
            this.lbCategory = new System.Windows.Forms.Label();
            this.lbSearch = new System.Windows.Forms.Label();
            this.lbProduct = new System.Windows.Forms.Label();
            this.lbTradeMark = new System.Windows.Forms.Label();
            this.lbProductMaterial = new System.Windows.Forms.Label();
            this.txtMadeIn = new System.Windows.Forms.TextBox();
            this.lbPrice = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.mnuQlySanPham = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTradeMark = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuNhapHang = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBanHang = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuProductMaterial = new System.Windows.Forms.ToolStripMenuItem();
            this.helpMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.contentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.indexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuColor = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSize = new System.Windows.Forms.ToolStripMenuItem();
            this.cboColor = new System.Windows.Forms.ComboBox();
            this.cboCategories = new System.Windows.Forms.ComboBox();
            this.cboTradeMark = new System.Windows.Forms.ComboBox();
            this.cboProductMaterial = new System.Windows.Forms.ComboBox();
            this.cboSize = new System.Windows.Forms.ComboBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.lbWelcome = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).BeginInit();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(1052, 288);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(79, 23);
            this.btnSearch.TabIndex = 28;
            this.btnSearch.Text = "Tìm kiếm";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dgvProducts
            // 
            this.dgvProducts.AllowUserToAddRows = false;
            this.dgvProducts.AllowUserToDeleteRows = false;
            this.dgvProducts.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvProducts.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProducts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductID,
            this.ProductName,
            this.CategoryName,
            this.TradeMarkName,
            this.ProductMaterials,
            this.Color,
            this.Size,
            this.Price,
            this.ProductQuantity,
            this.MadeIn,
            this.Description});
            this.dgvProducts.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvProducts.Location = new System.Drawing.Point(196, 318);
            this.dgvProducts.Margin = new System.Windows.Forms.Padding(2);
            this.dgvProducts.Name = "dgvProducts";
            this.dgvProducts.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvProducts.RowHeadersWidth = 62;
            this.dgvProducts.RowTemplate.Height = 28;
            this.dgvProducts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProducts.Size = new System.Drawing.Size(935, 267);
            this.dgvProducts.TabIndex = 23;
            this.dgvProducts.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProducts_RowEnter);
            // 
            // ProductID
            // 
            this.ProductID.DataPropertyName = "ProductID";
            this.ProductID.HeaderText = "Mã Sản phẩm";
            this.ProductID.Name = "ProductID";
            this.ProductID.Width = 50;
            // 
            // ProductName
            // 
            this.ProductName.DataPropertyName = "ProductName";
            this.ProductName.HeaderText = "Tên Sản phẩm";
            this.ProductName.Name = "ProductName";
            this.ProductName.Width = 150;
            // 
            // CategoryName
            // 
            this.CategoryName.DataPropertyName = "CategoryName";
            this.CategoryName.FillWeight = 16.62295F;
            this.CategoryName.HeaderText = "Loại Sản phẩm";
            this.CategoryName.Name = "CategoryName";
            this.CategoryName.Width = 70;
            // 
            // TradeMarkName
            // 
            this.TradeMarkName.DataPropertyName = "TradeMarkName";
            this.TradeMarkName.FillWeight = 69.8164F;
            this.TradeMarkName.HeaderText = "Thương hiệu";
            this.TradeMarkName.Name = "TradeMarkName";
            this.TradeMarkName.Width = 70;
            // 
            // ProductMaterials
            // 
            this.ProductMaterials.DataPropertyName = "ProductMaterials";
            this.ProductMaterials.FillWeight = 33.2459F;
            this.ProductMaterials.HeaderText = "Chất liệu sản phẩm";
            this.ProductMaterials.Name = "ProductMaterials";
            this.ProductMaterials.Width = 70;
            // 
            // Color
            // 
            this.Color.DataPropertyName = "Color";
            this.Color.FillWeight = 150.2715F;
            this.Color.HeaderText = "Màu sắc";
            this.Color.Name = "Color";
            this.Color.Width = 106;
            // 
            // Size
            // 
            this.Size.DataPropertyName = "Size";
            this.Size.HeaderText = "Size";
            this.Size.Name = "Size";
            this.Size.Width = 40;
            // 
            // Price
            // 
            this.Price.DataPropertyName = "Price";
            this.Price.HeaderText = "Giá bán(nghìn VND)";
            this.Price.Name = "Price";
            this.Price.Width = 70;
            // 
            // ProductQuantity
            // 
            this.ProductQuantity.DataPropertyName = "ProductQuantity";
            this.ProductQuantity.HeaderText = "Số lượng";
            this.ProductQuantity.Name = "ProductQuantity";
            this.ProductQuantity.Width = 78;
            // 
            // MadeIn
            // 
            this.MadeIn.DataPropertyName = "MadeIn";
            this.MadeIn.FillWeight = 327.2727F;
            this.MadeIn.HeaderText = "Xuất xứ";
            this.MadeIn.Name = "MadeIn";
            // 
            // Description
            // 
            this.Description.DataPropertyName = "Description";
            this.Description.FillWeight = 2.770492F;
            this.Description.HeaderText = "Mô tả";
            this.Description.Name = "Description";
            this.Description.Width = 50;
            // 
            // tbTradeMarkName
            // 
            this.tbTradeMarkName.AutoSize = true;
            this.tbTradeMarkName.Location = new System.Drawing.Point(349, 292);
            this.tbTradeMarkName.Margin = new System.Windows.Forms.Padding(2);
            this.tbTradeMarkName.Name = "tbTradeMarkName";
            this.tbTradeMarkName.Size = new System.Drawing.Size(169, 19);
            this.tbTradeMarkName.TabIndex = 32;
            this.tbTradeMarkName.TabStop = true;
            this.tbTradeMarkName.Text = "Tìm kiếm theo thương hiệu";
            this.tbTradeMarkName.UseVisualStyleBackColor = true;
            this.tbTradeMarkName.CheckedChanged += new System.EventHandler(this.tbTradeMarkName_CheckedChanged);
            // 
            // rbProductName
            // 
            this.rbProductName.AutoSize = true;
            this.rbProductName.Location = new System.Drawing.Point(154, 292);
            this.rbProductName.Margin = new System.Windows.Forms.Padding(2);
            this.rbProductName.Name = "rbProductName";
            this.rbProductName.Size = new System.Drawing.Size(176, 19);
            this.rbProductName.TabIndex = 31;
            this.rbProductName.TabStop = true;
            this.rbProductName.Text = "Tìm kiếm theo tên sản phẩm";
            this.rbProductName.UseVisualStyleBackColor = true;
            this.rbProductName.CheckedChanged += new System.EventHandler(this.rbProductName_CheckedChanged);
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(886, 207);
            this.txtDescription.Margin = new System.Windows.Forms.Padding(2);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(245, 54);
            this.txtDescription.TabIndex = 25;
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(794, 289);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(2);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(241, 23);
            this.txtSearch.TabIndex = 18;
            // 
            // txtProductName
            // 
            this.txtProductName.Location = new System.Drawing.Point(154, 75);
            this.txtProductName.Margin = new System.Windows.Forms.Padding(2);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(225, 23);
            this.txtProductName.TabIndex = 17;
            // 
            // lbDescription
            // 
            this.lbDescription.AutoSize = true;
            this.lbDescription.Location = new System.Drawing.Point(810, 212);
            this.lbDescription.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbDescription.Name = "lbDescription";
            this.lbDescription.Size = new System.Drawing.Size(41, 15);
            this.lbDescription.TabIndex = 16;
            this.lbDescription.Text = "Mô tả:";
            // 
            // lbSize
            // 
            this.lbSize.AutoSize = true;
            this.lbSize.Location = new System.Drawing.Point(810, 145);
            this.lbSize.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbSize.Name = "lbSize";
            this.lbSize.Size = new System.Drawing.Size(43, 15);
            this.lbSize.TabIndex = 15;
            this.lbSize.Text = "Size(*):";
            // 
            // lbColor
            // 
            this.lbColor.AutoSize = true;
            this.lbColor.Location = new System.Drawing.Point(810, 78);
            this.lbColor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbColor.Name = "lbColor";
            this.lbColor.Size = new System.Drawing.Size(67, 15);
            this.lbColor.TabIndex = 14;
            this.lbColor.Text = "Màu sắc(*):";
            // 
            // lbMadeIn
            // 
            this.lbMadeIn.AutoSize = true;
            this.lbMadeIn.Location = new System.Drawing.Point(490, 212);
            this.lbMadeIn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbMadeIn.Name = "lbMadeIn";
            this.lbMadeIn.Size = new System.Drawing.Size(63, 15);
            this.lbMadeIn.TabIndex = 13;
            this.lbMadeIn.Text = "Xuất xứ(*):";
            // 
            // lbCategory
            // 
            this.lbCategory.AutoSize = true;
            this.lbCategory.Location = new System.Drawing.Point(20, 145);
            this.lbCategory.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbCategory.Name = "lbCategory";
            this.lbCategory.Size = new System.Drawing.Size(101, 15);
            this.lbCategory.TabIndex = 12;
            this.lbCategory.Text = "Loại Sản phẩm(*):";
            // 
            // lbSearch
            // 
            this.lbSearch.AutoSize = true;
            this.lbSearch.Location = new System.Drawing.Point(20, 294);
            this.lbSearch.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbSearch.Name = "lbSearch";
            this.lbSearch.Size = new System.Drawing.Size(114, 15);
            this.lbSearch.TabIndex = 19;
            this.lbSearch.Text = "Tìm kiếm sản phẩm:";
            // 
            // lbProduct
            // 
            this.lbProduct.AutoSize = true;
            this.lbProduct.Location = new System.Drawing.Point(20, 78);
            this.lbProduct.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbProduct.Name = "lbProduct";
            this.lbProduct.Size = new System.Drawing.Size(97, 15);
            this.lbProduct.TabIndex = 11;
            this.lbProduct.Text = "Tên Sản phẩm(*):\r\n";
            // 
            // lbTradeMark
            // 
            this.lbTradeMark.AutoSize = true;
            this.lbTradeMark.Location = new System.Drawing.Point(490, 145);
            this.lbTradeMark.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbTradeMark.Name = "lbTradeMark";
            this.lbTradeMark.Size = new System.Drawing.Size(90, 15);
            this.lbTradeMark.TabIndex = 13;
            this.lbTradeMark.Text = "Thương hiệu(*):";
            // 
            // lbProductMaterial
            // 
            this.lbProductMaterial.AutoSize = true;
            this.lbProductMaterial.Location = new System.Drawing.Point(20, 212);
            this.lbProductMaterial.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbProductMaterial.Name = "lbProductMaterial";
            this.lbProductMaterial.Size = new System.Drawing.Size(126, 15);
            this.lbProductMaterial.TabIndex = 16;
            this.lbProductMaterial.Text = "Chất liệu Sản phẩm(*):";
            // 
            // txtMadeIn
            // 
            this.txtMadeIn.Location = new System.Drawing.Point(586, 207);
            this.txtMadeIn.Margin = new System.Windows.Forms.Padding(2);
            this.txtMadeIn.Name = "txtMadeIn";
            this.txtMadeIn.Size = new System.Drawing.Size(139, 23);
            this.txtMadeIn.TabIndex = 25;
            // 
            // lbPrice
            // 
            this.lbPrice.AutoSize = true;
            this.lbPrice.Location = new System.Drawing.Point(490, 78);
            this.lbPrice.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbPrice.Name = "lbPrice";
            this.lbPrice.Size = new System.Drawing.Size(63, 15);
            this.lbPrice.TabIndex = 13;
            this.lbPrice.Text = "Giá bán(*):";
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(586, 75);
            this.txtPrice.Margin = new System.Windows.Forms.Padding(2);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(137, 23);
            this.txtPrice.TabIndex = 21;
            // 
            // label11
            // 
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.Location = new System.Drawing.Point(21, 277);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(1110, 2);
            this.label11.TabIndex = 34;
            this.label11.Text = "label11";
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.SystemColors.ControlLight;
            this.menuStrip.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuQlySanPham,
            this.mnuTradeMark,
            this.mnuNhapHang,
            this.mnuBanHang,
            this.mnuProductMaterial,
            this.helpMenu,
            this.mnuColor,
            this.mnuSize});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.MdiWindowListItem = this.mnuProductMaterial;
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(1148, 25);
            this.menuStrip.TabIndex = 35;
            this.menuStrip.Text = "MenuStrip";
            // 
            // mnuQlySanPham
            // 
            this.mnuQlySanPham.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.mnuQlySanPham.Name = "mnuQlySanPham";
            this.mnuQlySanPham.Size = new System.Drawing.Size(125, 21);
            this.mnuQlySanPham.Text = "Quản lý sản phẩm";
            // 
            // mnuTradeMark
            // 
            this.mnuTradeMark.Name = "mnuTradeMark";
            this.mnuTradeMark.Size = new System.Drawing.Size(93, 21);
            this.mnuTradeMark.Text = "Thương hiệu";
            this.mnuTradeMark.Click += new System.EventHandler(this.mnuTradeMark_Click);
            // 
            // mnuNhapHang
            // 
            this.mnuNhapHang.Name = "mnuNhapHang";
            this.mnuNhapHang.Size = new System.Drawing.Size(105, 21);
            this.mnuNhapHang.Text = "Loại sản phẩm";
            this.mnuNhapHang.Click += new System.EventHandler(this.mnuNhapHang_Click);
            // 
            // mnuBanHang
            // 
            this.mnuBanHang.Name = "mnuBanHang";
            this.mnuBanHang.Size = new System.Drawing.Size(12, 21);
            // 
            // mnuProductMaterial
            // 
            this.mnuProductMaterial.Name = "mnuProductMaterial";
            this.mnuProductMaterial.Size = new System.Drawing.Size(131, 21);
            this.mnuProductMaterial.Text = "Chất liệu sản phẩm";
            this.mnuProductMaterial.Click += new System.EventHandler(this.mnuProductMaterial_Click);
            // 
            // helpMenu
            // 
            this.helpMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contentsToolStripMenuItem,
            this.indexToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.toolStripSeparator8,
            this.aboutToolStripMenuItem});
            this.helpMenu.Name = "helpMenu";
            this.helpMenu.Size = new System.Drawing.Size(12, 21);
            // 
            // contentsToolStripMenuItem
            // 
            this.contentsToolStripMenuItem.Name = "contentsToolStripMenuItem";
            this.contentsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F1)));
            this.contentsToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.contentsToolStripMenuItem.Text = "&Contents";
            // 
            // indexToolStripMenuItem
            // 
            this.indexToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("indexToolStripMenuItem.Image")));
            this.indexToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.indexToolStripMenuItem.Name = "indexToolStripMenuItem";
            this.indexToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.indexToolStripMenuItem.Text = "&Index";
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("searchToolStripMenuItem.Image")));
            this.searchToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.searchToolStripMenuItem.Text = "&Search";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(174, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.aboutToolStripMenuItem.Text = "&About ... ...";
            // 
            // mnuColor
            // 
            this.mnuColor.Name = "mnuColor";
            this.mnuColor.Size = new System.Drawing.Size(107, 21);
            this.mnuColor.Text = "Màu sản phẩm";
            this.mnuColor.Click += new System.EventHandler(this.mnuColor_Click);
            // 
            // mnuSize
            // 
            this.mnuSize.Name = "mnuSize";
            this.mnuSize.Size = new System.Drawing.Size(43, 21);
            this.mnuSize.Text = "Size";
            this.mnuSize.Click += new System.EventHandler(this.mnuSize_Click);
            // 
            // cboColor
            // 
            this.cboColor.FormattingEnabled = true;
            this.cboColor.Location = new System.Drawing.Point(886, 75);
            this.cboColor.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cboColor.Name = "cboColor";
            this.cboColor.Size = new System.Drawing.Size(245, 23);
            this.cboColor.TabIndex = 36;
            // 
            // cboCategories
            // 
            this.cboCategories.FormattingEnabled = true;
            this.cboCategories.Location = new System.Drawing.Point(154, 142);
            this.cboCategories.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cboCategories.Name = "cboCategories";
            this.cboCategories.Size = new System.Drawing.Size(225, 23);
            this.cboCategories.TabIndex = 36;
            // 
            // cboTradeMark
            // 
            this.cboTradeMark.FormattingEnabled = true;
            this.cboTradeMark.Location = new System.Drawing.Point(586, 142);
            this.cboTradeMark.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cboTradeMark.Name = "cboTradeMark";
            this.cboTradeMark.Size = new System.Drawing.Size(137, 23);
            this.cboTradeMark.TabIndex = 36;
            // 
            // cboProductMaterial
            // 
            this.cboProductMaterial.FormattingEnabled = true;
            this.cboProductMaterial.Location = new System.Drawing.Point(154, 207);
            this.cboProductMaterial.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cboProductMaterial.Name = "cboProductMaterial";
            this.cboProductMaterial.Size = new System.Drawing.Size(225, 23);
            this.cboProductMaterial.TabIndex = 36;
            // 
            // cboSize
            // 
            this.cboSize.FormattingEnabled = true;
            this.cboSize.Location = new System.Drawing.Point(886, 142);
            this.cboSize.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cboSize.Name = "cboSize";
            this.cboSize.Size = new System.Drawing.Size(245, 23);
            this.cboSize.TabIndex = 36;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(99, 503);
            this.btnClose.Margin = new System.Windows.Forms.Padding(2);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(72, 36);
            this.btnClose.TabIndex = 107;
            this.btnClose.Text = "Thoát";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(22, 503);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(72, 36);
            this.btnDelete.TabIndex = 106;
            this.btnDelete.Text = "Xóa";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(99, 353);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(72, 36);
            this.btnSave.TabIndex = 102;
            this.btnSave.Text = "Ghi";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(22, 353);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(72, 36);
            this.btnAdd.TabIndex = 103;
            this.btnAdd.Text = "Thêm mới";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(99, 428);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(72, 36);
            this.btnCancel.TabIndex = 104;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(22, 428);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(2);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(72, 36);
            this.btnEdit.TabIndex = 105;
            this.btnEdit.Text = "Sửa";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // lbWelcome
            // 
            this.lbWelcome.BackColor = System.Drawing.Color.LightGray;
            this.lbWelcome.Cursor = System.Windows.Forms.Cursors.Default;
            this.lbWelcome.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbWelcome.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbWelcome.ImeMode = System.Windows.Forms.ImeMode.On;
            this.lbWelcome.Location = new System.Drawing.Point(0, 25);
            this.lbWelcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbWelcome.Name = "lbWelcome";
            this.lbWelcome.Size = new System.Drawing.Size(1148, 35);
            this.lbWelcome.TabIndex = 108;
            this.lbWelcome.Text = "SẢN PHẨM";
            this.lbWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbWelcome.UseCompatibleTextRendering = true;
            // 
            // frmProducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1148, 587);
            this.Controls.Add(this.lbWelcome);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.cboProductMaterial);
            this.Controls.Add(this.cboTradeMark);
            this.Controls.Add(this.cboCategories);
            this.Controls.Add(this.cboSize);
            this.Controls.Add(this.cboColor);
            this.Controls.Add(this.menuStrip);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.dgvProducts);
            this.Controls.Add(this.tbTradeMarkName);
            this.Controls.Add(this.rbProductName);
            this.Controls.Add(this.txtMadeIn);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.lbProductMaterial);
            this.Controls.Add(this.txtProductName);
            this.Controls.Add(this.lbDescription);
            this.Controls.Add(this.lbSize);
            this.Controls.Add(this.lbTradeMark);
            this.Controls.Add(this.lbColor);
            this.Controls.Add(this.lbPrice);
            this.Controls.Add(this.lbMadeIn);
            this.Controls.Add(this.lbCategory);
            this.Controls.Add(this.lbSearch);
            this.Controls.Add(this.lbProduct);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "frmProducts";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý sản phẩm";
            this.Load += new System.EventHandler(this.frmProducts_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).EndInit();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView dgvProducts;
        private System.Windows.Forms.RadioButton tbTradeMarkName;
        private System.Windows.Forms.RadioButton rbProductName;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label lbDescription;
        private System.Windows.Forms.Label lbSize;
        private System.Windows.Forms.Label lbColor;
        private System.Windows.Forms.Label lbMadeIn;
        private System.Windows.Forms.Label lbCategory;
        private System.Windows.Forms.Label lbSearch;
        private System.Windows.Forms.Label lbProduct;
        private System.Windows.Forms.Label lbTradeMark;
        private System.Windows.Forms.Label lbProductMaterial;
        private System.Windows.Forms.TextBox txtMadeIn;
        private System.Windows.Forms.Label lbPrice;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem mnuQlySanPham;
        private System.Windows.Forms.ToolStripMenuItem mnuTradeMark;
        private System.Windows.Forms.ToolStripMenuItem mnuNhapHang;
        private System.Windows.Forms.ToolStripMenuItem mnuBanHang;
        private System.Windows.Forms.ToolStripMenuItem mnuProductMaterial;
        private System.Windows.Forms.ToolStripMenuItem helpMenu;
        private System.Windows.Forms.ToolStripMenuItem contentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem indexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ComboBox cboColor;
        private System.Windows.Forms.ComboBox cboCategories;
        private System.Windows.Forms.ComboBox cboTradeMark;
        private System.Windows.Forms.ComboBox cboProductMaterial;
        private System.Windows.Forms.ComboBox cboSize;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.ToolStripMenuItem mnuColor;
        private System.Windows.Forms.ToolStripMenuItem mnuSize;
        private System.Windows.Forms.Label lbWelcome;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn CategoryName;
        private System.Windows.Forms.DataGridViewTextBoxColumn TradeMarkName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductMaterials;
        private System.Windows.Forms.DataGridViewTextBoxColumn Color;
        private System.Windows.Forms.DataGridViewTextBoxColumn Size;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn MadeIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
    }
}