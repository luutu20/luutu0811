﻿namespace frmDA01
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.mnuProducts = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuUser = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOrder = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSales = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuStatitics = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.lbWelcome = new System.Windows.Forms.Label();
            this.lbOrders = new System.Windows.Forms.Label();
            this.lbSales = new System.Windows.Forms.Label();
            this.lbStatistics = new System.Windows.Forms.Label();
            this.lbUsers = new System.Windows.Forms.Label();
            this.lbProducts = new System.Windows.Forms.Label();
            this.btnStatistics = new System.Windows.Forms.Button();
            this.btnSales = new System.Windows.Forms.Button();
            this.btnOrders = new System.Windows.Forms.Button();
            this.btnProducts = new System.Windows.Forms.Button();
            this.btnUsers = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbTime = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.AutoSize = false;
            this.menuStrip.BackColor = System.Drawing.SystemColors.ControlLight;
            this.menuStrip.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuProducts,
            this.mnuUser,
            this.mnuOrder,
            this.mnuSales,
            this.mnuStatitics});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.MdiWindowListItem = this.mnuStatitics;
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(1336, 28);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // mnuProducts
            // 
            this.mnuProducts.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.mnuProducts.Name = "mnuProducts";
            this.mnuProducts.Size = new System.Drawing.Size(125, 24);
            this.mnuProducts.Text = "Quản lý sản phẩm";
            this.mnuProducts.Click += new System.EventHandler(this.mnuProducts_Click);
            // 
            // mnuUser
            // 
            this.mnuUser.Name = "mnuUser";
            this.mnuUser.Size = new System.Drawing.Size(123, 24);
            this.mnuUser.Text = "Quản lý nhân viên";
            this.mnuUser.Click += new System.EventHandler(this.mnuUser_Click);
            // 
            // mnuOrder
            // 
            this.mnuOrder.Name = "mnuOrder";
            this.mnuOrder.Size = new System.Drawing.Size(85, 24);
            this.mnuOrder.Text = "Nhập hàng";
            this.mnuOrder.Click += new System.EventHandler(this.mnuOrder_Click);
            // 
            // mnuSales
            // 
            this.mnuSales.Name = "mnuSales";
            this.mnuSales.Size = new System.Drawing.Size(74, 24);
            this.mnuSales.Text = "Bán hàng";
            this.mnuSales.Click += new System.EventHandler(this.mnuSales_Click);
            // 
            // mnuStatitics
            // 
            this.mnuStatitics.Name = "mnuStatitics";
            this.mnuStatitics.Size = new System.Drawing.Size(74, 24);
            this.mnuStatitics.Text = "Thống kê";
            // 
            // lbWelcome
            // 
            this.lbWelcome.BackColor = System.Drawing.SystemColors.Control;
            this.lbWelcome.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lbWelcome.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbWelcome.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbWelcome.ImeMode = System.Windows.Forms.ImeMode.On;
            this.lbWelcome.Location = new System.Drawing.Point(0, 28);
            this.lbWelcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbWelcome.Name = "lbWelcome";
            this.lbWelcome.Size = new System.Drawing.Size(1336, 35);
            this.lbWelcome.TabIndex = 1;
            this.lbWelcome.Text = "CHÀO MỪNG BẠN ĐẾN VỚI HỆ THỐNG QUẢN TRỊ";
            this.lbWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbWelcome.UseCompatibleTextRendering = true;
            // 
            // lbOrders
            // 
            this.lbOrders.AutoEllipsis = true;
            this.lbOrders.AutoSize = true;
            this.lbOrders.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lbOrders.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbOrders.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbOrders.ImeMode = System.Windows.Forms.ImeMode.On;
            this.lbOrders.Location = new System.Drawing.Point(12, 430);
            this.lbOrders.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbOrders.Name = "lbOrders";
            this.lbOrders.Size = new System.Drawing.Size(89, 21);
            this.lbOrders.TabIndex = 9;
            this.lbOrders.Text = "Nhập hàng";
            this.lbOrders.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbOrders.Click += new System.EventHandler(this.lbOrders_Click);
            // 
            // lbSales
            // 
            this.lbSales.AutoEllipsis = true;
            this.lbSales.AutoSize = true;
            this.lbSales.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lbSales.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbSales.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbSales.ImeMode = System.Windows.Forms.ImeMode.On;
            this.lbSales.Location = new System.Drawing.Point(18, 562);
            this.lbSales.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbSales.Name = "lbSales";
            this.lbSales.Size = new System.Drawing.Size(77, 21);
            this.lbSales.TabIndex = 10;
            this.lbSales.Text = "Bán hàng";
            this.lbSales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbSales.Click += new System.EventHandler(this.lbSales_Click);
            // 
            // lbStatistics
            // 
            this.lbStatistics.AutoSize = true;
            this.lbStatistics.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lbStatistics.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbStatistics.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbStatistics.ImeMode = System.Windows.Forms.ImeMode.On;
            this.lbStatistics.Location = new System.Drawing.Point(17, 690);
            this.lbStatistics.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbStatistics.Name = "lbStatistics";
            this.lbStatistics.Size = new System.Drawing.Size(78, 21);
            this.lbStatistics.TabIndex = 11;
            this.lbStatistics.Text = "Thống kê";
            this.lbStatistics.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbStatistics.Click += new System.EventHandler(this.lbStatistics_Click);
            // 
            // lbUsers
            // 
            this.lbUsers.AutoEllipsis = true;
            this.lbUsers.AutoSize = true;
            this.lbUsers.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lbUsers.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbUsers.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbUsers.ImeMode = System.Windows.Forms.ImeMode.On;
            this.lbUsers.Location = new System.Drawing.Point(15, 298);
            this.lbUsers.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUsers.Name = "lbUsers";
            this.lbUsers.Size = new System.Drawing.Size(82, 21);
            this.lbUsers.TabIndex = 8;
            this.lbUsers.Text = "Nhân viên";
            this.lbUsers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbUsers.Click += new System.EventHandler(this.lbUsers_Click);
            // 
            // lbProducts
            // 
            this.lbProducts.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbProducts.AutoEllipsis = true;
            this.lbProducts.AutoSize = true;
            this.lbProducts.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lbProducts.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbProducts.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbProducts.ImeMode = System.Windows.Forms.ImeMode.On;
            this.lbProducts.Location = new System.Drawing.Point(16, 166);
            this.lbProducts.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbProducts.Name = "lbProducts";
            this.lbProducts.Size = new System.Drawing.Size(81, 21);
            this.lbProducts.TabIndex = 7;
            this.lbProducts.Text = "Sản phẩm";
            this.lbProducts.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbProducts.Click += new System.EventHandler(this.lbProducts_Click);
            // 
            // btnStatistics
            // 
            this.btnStatistics.AutoSize = true;
            this.btnStatistics.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnStatistics.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnStatistics.BackgroundImage")));
            this.btnStatistics.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnStatistics.ImeMode = System.Windows.Forms.ImeMode.On;
            this.btnStatistics.Location = new System.Drawing.Point(13, 602);
            this.btnStatistics.Margin = new System.Windows.Forms.Padding(0);
            this.btnStatistics.Name = "btnStatistics";
            this.btnStatistics.Size = new System.Drawing.Size(86, 83);
            this.btnStatistics.TabIndex = 6;
            this.btnStatistics.UseVisualStyleBackColor = false;
            this.btnStatistics.Click += new System.EventHandler(this.btnStatistics_Click);
            // 
            // btnSales
            // 
            this.btnSales.AutoSize = true;
            this.btnSales.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnSales.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSales.BackgroundImage")));
            this.btnSales.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSales.ForeColor = System.Drawing.Color.White;
            this.btnSales.ImeMode = System.Windows.Forms.ImeMode.On;
            this.btnSales.Location = new System.Drawing.Point(13, 477);
            this.btnSales.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSales.Name = "btnSales";
            this.btnSales.Size = new System.Drawing.Size(86, 83);
            this.btnSales.TabIndex = 5;
            this.btnSales.UseVisualStyleBackColor = false;
            this.btnSales.Click += new System.EventHandler(this.btnSales_Click);
            // 
            // btnOrders
            // 
            this.btnOrders.AutoSize = true;
            this.btnOrders.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnOrders.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnOrders.BackgroundImage")));
            this.btnOrders.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnOrders.ImeMode = System.Windows.Forms.ImeMode.On;
            this.btnOrders.Location = new System.Drawing.Point(13, 345);
            this.btnOrders.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnOrders.Name = "btnOrders";
            this.btnOrders.Size = new System.Drawing.Size(86, 83);
            this.btnOrders.TabIndex = 4;
            this.btnOrders.UseVisualStyleBackColor = false;
            this.btnOrders.Click += new System.EventHandler(this.btnOrders_Click);
            // 
            // btnProducts
            // 
            this.btnProducts.AutoSize = true;
            this.btnProducts.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnProducts.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnProducts.BackgroundImage")));
            this.btnProducts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnProducts.ImeMode = System.Windows.Forms.ImeMode.On;
            this.btnProducts.Location = new System.Drawing.Point(13, 78);
            this.btnProducts.Margin = new System.Windows.Forms.Padding(0);
            this.btnProducts.Name = "btnProducts";
            this.btnProducts.Size = new System.Drawing.Size(86, 83);
            this.btnProducts.TabIndex = 2;
            this.btnProducts.UseVisualStyleBackColor = false;
            this.btnProducts.Click += new System.EventHandler(this.btnProducts_Click);
            // 
            // btnUsers
            // 
            this.btnUsers.AutoSize = true;
            this.btnUsers.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnUsers.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUsers.BackgroundImage")));
            this.btnUsers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnUsers.ImeMode = System.Windows.Forms.ImeMode.On;
            this.btnUsers.Location = new System.Drawing.Point(13, 211);
            this.btnUsers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnUsers.Name = "btnUsers";
            this.btnUsers.Size = new System.Drawing.Size(86, 83);
            this.btnUsers.TabIndex = 3;
            this.btnUsers.UseVisualStyleBackColor = false;
            this.btnUsers.Click += new System.EventHandler(this.btnUsers_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbTime
            // 
            this.lbTime.AutoSize = true;
            this.lbTime.Enabled = false;
            this.lbTime.Font = new System.Drawing.Font("Segoe UI Semibold", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTime.LiveSetting = System.Windows.Forms.Automation.AutomationLiveSetting.Polite;
            this.lbTime.Location = new System.Drawing.Point(967, 664);
            this.lbTime.Name = "lbTime";
            this.lbTime.Size = new System.Drawing.Size(212, 47);
            this.lbTime.TabIndex = 15;
            this.lbTime.Text = "Thời gian là:";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Location = new System.Drawing.Point(149, 64);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1169, 597);
            this.panel1.TabIndex = 16;
            // 
            // frmMain
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1336, 713);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbTime);
            this.Controls.Add(this.lbStatistics);
            this.Controls.Add(this.lbSales);
            this.Controls.Add(this.lbProducts);
            this.Controls.Add(this.lbUsers);
            this.Controls.Add(this.lbOrders);
            this.Controls.Add(this.lbWelcome);
            this.Controls.Add(this.menuStrip);
            this.Controls.Add(this.btnStatistics);
            this.Controls.Add(this.btnSales);
            this.Controls.Add(this.btnOrders);
            this.Controls.Add(this.btnUsers);
            this.Controls.Add(this.btnProducts);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hệ thống quản trị";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem mnuProducts;
        private System.Windows.Forms.ToolStripMenuItem mnuUser;
        private System.Windows.Forms.ToolStripMenuItem mnuOrder;
        private System.Windows.Forms.ToolStripMenuItem mnuSales;
        private System.Windows.Forms.ToolStripMenuItem mnuStatitics;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Label lbWelcome;
        private System.Windows.Forms.Button btnProducts;
        private System.Windows.Forms.Label lbOrders;
        private System.Windows.Forms.Button btnOrders;
        private System.Windows.Forms.Button btnSales;
        private System.Windows.Forms.Button btnStatistics;
        private System.Windows.Forms.Label lbSales;
        private System.Windows.Forms.Label lbStatistics;
        private System.Windows.Forms.Label lbUsers;
        private System.Windows.Forms.Label lbProducts;
        private System.Windows.Forms.Button btnUsers;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lbTime;
        private System.Windows.Forms.Panel panel1;
    }
}



