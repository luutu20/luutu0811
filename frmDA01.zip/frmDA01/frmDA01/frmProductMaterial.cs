﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmDA01
{
    public partial class frmProductMaterial : Form
    {
        private DataServices myDataservies = new DataServices();
        private DataTable dtProductMaterials;
        private bool modeNew;
        private string oldProductMaterial;
        public frmProductMaterial()
        {
            InitializeComponent();
        }

        private void frmProductMaterial_Load(object sender, EventArgs e)
        {
            myDataservies.OpenDB();

            disPlay();
            setControl(false);
        }

        private void disPlay()
        {
            string sSql = "SELECT * FROM ProductMaterials ORDER BY ProductMaterials";
            dtProductMaterials = myDataservies.RunQuery(sSql);
            dgvProductMaterials.AutoGenerateColumns = false;
            dgvProductMaterials.DataSource = dtProductMaterials;
        }
        private void setControl(bool edit)
        {
            txtProductMaterial.Enabled = edit;
            txtDescription.Enabled = edit;

            btnAdd.Enabled = !edit;
            btnEdit.Enabled = !edit;
            btnDelete.Enabled = !edit;
            btnCancel.Enabled = edit;
            btnSave.Enabled = edit;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            modeNew = true;
            setControl(true);

            txtProductMaterial.Clear();
            txtDescription.Clear();

            txtProductMaterial.Focus();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            modeNew = false;
            setControl(true);
            txtProductMaterial.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            setControl(false);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dgvProductMaterials_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtProductMaterial.Text = dgvProductMaterials.Rows[e.RowIndex].Cells["ProductMaterials"].Value.ToString();
            txtDescription.Text = dgvProductMaterials.Rows[e.RowIndex].Cells["Description"].Value.ToString();

            oldProductMaterial = txtProductMaterial.Text;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //xác nhận xóa dữ liệu không
            DialogResult dr;
            dr = MessageBox.Show("Chắc chắn xóa dòng đã chọn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No) return;

            //xóa dữ liệu
            //1. Lấy dòng dữ liệu muốn xóa
            int r = dgvProductMaterials.CurrentRow.Index;
            //2.Lấy ProductMaterialID
            string ProductMaterialID = dgvProductMaterials.Rows[r].Cells[0].Value.ToString();
            //Câu lệnh xóa
            string sSql = "DELETE FROM ProductMaterials WHERE ProductMaterialID = '" + ProductMaterialID + "'";
            //Xóa
            myDataservies.ExecuteNonQuery(sSql);
            //hiện thị lại
            disPlay();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtProductMaterial.Text.Trim() == "")
            {
                MessageBox.Show("Nhập chất liệu sản phẩm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtProductMaterial.Focus();
                return;
            }
            //kiểm tra trùng ProductMaterial
            if ((modeNew == true) || (modeNew == false) && (txtProductMaterial.Text.Trim() != oldProductMaterial.Trim()))
            {
                string sSql = "SELECT ProductMaterials FROM ProductMaterials WHERE ProductMaterials = N'" + txtProductMaterial.Text + "'";
                DataServices myDataservies = new DataServices();
                DataTable dtSearch = myDataservies.RunQuery(sSql);
                if (dtSearch.Rows.Count > 0)
                {
                    MessageBox.Show("Đã nhập/sửa trùng loại sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtProductMaterial.Focus();
                    return;
                }

                if (modeNew == true)
                {
                    //thêm dữ liệu
                    string ssSql = "INSERT INTO ProductMaterials(ProductMaterials,Description) VALUES (N'" + txtProductMaterial.Text + "',N'" + txtDescription.Text + "')";
                    myDataservies.ExecuteNonQuery(ssSql);
                }
                else
                {
                    //sửa dữ liệu
                    //lấy dòng cần sửa
                    int r = dgvProductMaterials.CurrentRow.Index;
                    //Lấy mã ID cần sửa
                    string ProductMaterialID = dgvProductMaterials.Rows[r].Cells[0].Value.ToString();
                    //Lệnh sửa
                    string ssSql = "UPDATE ProductMaterials SET ProductMaterials = N'" + txtProductMaterial.Text + "',Description = N'" + txtDescription.Text + "' WHERE ProductMaterialID = '" + ProductMaterialID + "'";
                    myDataservies.ExecuteNonQuery(ssSql);
                }
                disPlay();

                setControl(false);
            }
        }
    }
}
