﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmDA01
{
    public partial class frmCategories : Form
    {
        private DataServices mydataservies;
        private DataTable dtCategories;
        private bool modnew;
        private string oldCategory;

        public frmCategories()
        {
            InitializeComponent();
        }

        private void frmCategories_Load(object sender, EventArgs e)
        {
            mydataservies = new DataServices();
            if (mydataservies.OpenDB() == false) return;
            //lấy dữ liệu lên view
            display();

            SetControl(false);
        }

        private void SetControl(bool edit)
        {
            txtCategory.Enabled = edit;
            txtDescription.Enabled = edit;

            btnAdd.Enabled = !edit;
            btnEdit.Enabled = !edit;
            btnDelete.Enabled = !edit;
            btnCancel.Enabled = edit;
            btnSave.Enabled = edit;
        }

        private void display()
        {
            string sSql = "SELECT * FROM Categories ORDER BY CategoryName";
            dtCategories = mydataservies.RunQuery(sSql);
            dgvCategories.AutoGenerateColumns = false;
            dgvCategories.DataSource = dtCategories;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            modnew = true;
            SetControl(true);

            txtCategory.Clear();
            txtDescription.Clear();

            txtCategory.Focus();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            modnew = false;
            SetControl(true);
            txtCategory.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            SetControl(false);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dgvCategories_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtCategory.Text = dgvCategories.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtDescription.Text = dgvCategories.Rows[e.RowIndex].Cells[2].Value.ToString();

            oldCategory = txtCategory.Text;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //xác nhận xóa dữ liệu không
            DialogResult dr;
            dr = MessageBox.Show("Chắc chắn xóa dòng đã chọn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No) return;

            //xóa dữ liệu
            //1. Lấy dòng dữ liệu muốn xóa
            int r = dgvCategories.CurrentRow.Index;
            //2.Lấy TradeMarkID
            string CategoryID = dgvCategories.Rows[r].Cells[0].Value.ToString();
            //Câu lệnh xóa
            string sSql = "DELETE FROM Categories WHERE CategoryID = '" + CategoryID + "'";
            //Xóa
            mydataservies.ExecuteNonQuery(sSql);
            //hiện thị lại
            display();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtCategory.Text.Trim() == "")
            {
                MessageBox.Show("Nhập loại sản phẩm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCategory.Focus();
                return;
            }
            //kiểm tra trùng TradeMarkName
            if ((modnew == true) || (modnew == false) && (txtCategory.Text.Trim() != oldCategory.Trim()))
            {
                string sSql = "SELECT CategoryName FROM Categories WHERE CategoryName = N'" + txtCategory.Text + "'";
                DataServices myDataservies = new DataServices();
                DataTable dtSearch = myDataservies.RunQuery(sSql);
                if (dtSearch.Rows.Count > 0)
                {
                    MessageBox.Show("Đã nhập/sửa trùng loại sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCategory.Focus();
                    return;
                }

                if (modnew == true)
                {
                    //thêm dữ liệu
                    string ssSql = "INSERT INTO Categories(CategoryName,Description) VALUES (N'" + txtCategory.Text + "',N'" + txtDescription.Text + "')";
                    mydataservies.ExecuteNonQuery(ssSql);
                }
                else
                {
                    //sửa dữ liệu
                    //lấy dòng cần sửa
                    int r = dgvCategories.CurrentRow.Index;
                    //Lấy mã ID cần sửa
                    string CategoryID = dgvCategories.Rows[r].Cells[0].Value.ToString();
                    //Lệnh sửa
                    string ssSql = "UPDATE Categories SET CategoryName = N'" +txtCategory.Text + "',Description = N'" + txtDescription.Text + "' WHERE CategoryID = '" + CategoryID + "'";
                    mydataservies.ExecuteNonQuery(ssSql);
                }
                display();

                SetControl(false);
            }
        }
    }
}
