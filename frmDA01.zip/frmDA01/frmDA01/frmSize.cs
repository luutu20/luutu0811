﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmDA01
{
    public partial class frmSize : Form
    {
        private DataServices myDataservies = new DataServices();
        private DataTable dtSize;
        private bool modeNew;
        private string oldSize;
        public frmSize()
        {
            InitializeComponent();
        }

        private void frmSize_Load(object sender, EventArgs e)
        {
            myDataservies.OpenDB();

            disPlay();
            setControl(false);
        }
        private void disPlay()
        {
            string sSql = "SELECT * FROM Size ORDER BY Size";
            dtSize = myDataservies.RunQuery(sSql);
            dgvSize.AutoGenerateColumns = false;
            dgvSize.DataSource = dtSize;
        }    
         private void setControl(bool edit)
        {
            txtSize.Enabled = edit;
            txtDescription.Enabled = edit;

            btnAdd.Enabled = !edit;
            btnEdit.Enabled = !edit;
            btnDelete.Enabled = !edit;
            btnCancel.Enabled = edit;
            btnSave.Enabled = edit;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            modeNew = true;
            setControl(true);

            txtSize.Clear();
            txtDescription.Clear();

            txtSize.Focus();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            modeNew = false;
            setControl(true);
            txtSize.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            setControl(false);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //xác nhận xóa dữ liệu không
            DialogResult dr;
            dr = MessageBox.Show("Chắc chắn xóa dòng đã chọn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No) return;

            //xóa dữ liệu
            //1. Lấy dòng dữ liệu muốn xóa
            int r = dgvSize.CurrentRow.Index;
            //2.Lấy TradeMarkID
            string SizeID = dgvSize.Rows[r].Cells[0].Value.ToString();
            //Câu lệnh xóa
            string sSql = "DELETE FROM Size WHERE SizeID = '" + SizeID + "'";
            //Xóa
            myDataservies.ExecuteNonQuery(sSql);
            //hiện thị lại
            disPlay();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtSize.Text.Trim() == "")
            {
                MessageBox.Show("Nhập Size sản phẩm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSize.Focus();
                return;
            }
            //kiểm tra trùng TradeMarkName
            if ((modeNew == true) || (modeNew == false) && (txtSize.Text.Trim() != oldSize.Trim()))
            {
                string sSql = "SELECT Size FROM Size WHERE Size = N'" + txtSize.Text + "'";
                DataServices myDataservies = new DataServices();
                DataTable dtSearch = myDataservies.RunQuery(sSql);
                if (dtSearch.Rows.Count > 0)
                {
                    MessageBox.Show("Đã nhập/sửa trùng loại sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtSize.Focus();
                    return;
                }

                if (modeNew == true)
                {
                    //thêm dữ liệu
                    string ssSql = "INSERT INTO Size(Size,Description) VALUES (N'" + txtSize.Text + "',N'" + txtDescription.Text + "')";
                    myDataservies.ExecuteNonQuery(ssSql);
                }
                else
                {
                    //sửa dữ liệu
                    //lấy dòng cần sửa
                    int r = dgvSize.CurrentRow.Index;
                    //Lấy mã ID cần sửa
                    string SizeID = dgvSize.Rows[r].Cells[0].Value.ToString();
                    //Lệnh sửa
                    string ssSql = "UPDATE Size SET Color = N'" + txtSize.Text + "',Description = N'" + txtDescription.Text + "' WHERE SizeID = '" + SizeID + "'";
                    myDataservies.ExecuteNonQuery(ssSql);
                }
                disPlay();

                setControl(false);
            }
        }

        private void dgvSize_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtSize.Text = dgvSize.Rows[e.RowIndex].Cells["Size"].Value.ToString();
            txtDescription.Text = dgvSize.Rows[e.RowIndex].Cells["Description"].Value.ToString();

            oldSize = txtSize.Text;
        }
    }
}
