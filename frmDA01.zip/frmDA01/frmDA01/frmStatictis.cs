﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmDA01
{
    public partial class frmStatictis : Form
    {
        private DataServices staDataServices = new DataServices();
        private DataTable dtProducts,dtSales;
        public frmStatictis()
        {
            InitializeComponent();
        }

        private void frmStatictis_Load(object sender, EventArgs e)
        {
            staDataServices.OpenDB();

            string sSql = "SELECT ProductID,ProductName,ProductQuantity from Products";
            dtProducts = staDataServices.RunQuery(sSql);
            dgvProductQuantity.DataSource = dtProducts;

            string[] options = { "Thống kê theo ngày", "Thống kê theo tháng", "Thống kê theo năm" };
            cboStatictis.Items.AddRange(options);
            cboStatictis.SelectedIndex = 0;
        }

        private void totalPayment()
        {
            int sum = 0;
            for (int i = 0; i < dgvStatistics.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(dgvStatistics.Rows[i].Cells["TotalPayMent"].Value);
            }
            lbDisplay.Text = sum.ToString();
        }

        private void btnStatictis_Click(object sender, EventArgs e)
        {
            string options = cboStatictis.SelectedItem.ToString();
            
            if (options == "Thống kê theo ngày")
            {
                string SaleDate = txtStatictis.Text;
                DateTime date = DateTime.ParseExact(SaleDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                int day = date.Day;
                int month = date.Month;
                int year = date.Year;
                string sSql = "SELECT SaleID,CustomerName, TotalPayment, SaleDate  FROM Sales WHERE DAY(SaleDate) =" + day + " AND MONTH(SaleDate) =" + month + " AND YEAR(SaleDate) =" + year + ";";
                dtSales = staDataServices.RunQuery(sSql);
                dgvStatistics.DataSource = dtSales;
                totalPayment();
            }
            else if (options == "Thống kê theo tháng")
            {
                string SaleDate = txtStatictis.Text;
                DateTime date = DateTime.ParseExact(SaleDate, "MM/yyyy", CultureInfo.InvariantCulture);
                
                int month = date.Month;
                int year = date.Year;
                string sSql = "SELECT SaleID,CustomerName, TotalPayment, SaleDate  FROM Sales WHERE MONTH(SaleDate) =" + month + " AND YEAR(SaleDate) =" + year + ";";
                dtSales = staDataServices.RunQuery(sSql);
                dgvStatistics.DataSource = dtSales;
                totalPayment();
            }
            if (options == "Thống kê theo năm")
            {
                string SaleDate = txtStatictis.Text;
                DateTime date = DateTime.ParseExact(SaleDate, "yyyy", CultureInfo.InvariantCulture);
                int year = date.Year;

                string sSql = "SELECT SaleID,CustomerName, TotalPayment, SaleDate  FROM Sales WHERE YEAR(SaleDate) =" + year + ";";
                dtSales = staDataServices.RunQuery(sSql);
                dgvStatistics.DataSource = dtSales;
                totalPayment();
            }
        }
    }
}
