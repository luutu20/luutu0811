﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace frmDA01
{
    public partial class frmSales : Form
    {
        private DataServices myDataservies = new DataServices();
        private DataTable dtSales, dtSaleDetails;
        private bool modNew;
        
        public frmSales()
        {
            InitializeComponent();
        }

        private void frmSales_Load(object sender, EventArgs e)
        {
            myDataservies.OpenDB();
            string sSql;
            string UserID = frmLogin.UserID;

            sSql = "SELECT FullName FROM Users WHERE UserID = " + UserID + "";
            DataTable result = myDataservies.RunQuery(sSql);
            if (result.Rows.Count > 0)
            {
                // Giả sử cột FullName trong result chứa giá trị bạn muốn hiển thị
                string fullName = result.Rows[0]["FullName"].ToString();
                lbUser.Text = fullName;
            }
            //Đưa dữ liệu lên ComboBox ProductName
            sSql = "Select * from Products order by ProductName";
            DataTable dtProducts = myDataservies.RunQuery(sSql);
            cboProductName.DataSource = dtProducts;
            cboProductName.DisplayMember = "ProductName";
            cboProductName.ValueMember = "ProductID";

            sSql = "Select * from Sales order by SaleID";
            DataTable dtSaleID = myDataservies.RunQuery(sSql);
            cboSaleID.DataSource = dtSaleID;
            cboSaleID.DisplayMember = "SaleID";
            cboSaleID.ValueMember = "SaleID";

            SetControl(false);
            disPlaySaleDetails();
            disPlay();
        }

        private void SetControl(bool edit)
        {
            txtCustomerName.Enabled = edit;
            txtCustomerPhone.Enabled = edit;
            dtpSaleDate.Enabled = edit;
            txtDescription.Enabled = edit;
            
            btnAdd.Enabled = !edit;
            btnCancel.Enabled = edit;
            btnDelete.Enabled = !edit;
            btnSave.Enabled = edit;
            btnEdit.Enabled = !edit;
            
        }

        private void disPlay()
        {
            //Truy vấn dữ liệu
            string sSql = "SELECT SaleID,FullName,CustomerName,CustomerPhone,SaleDate,TotalPayment,Sales.Description \n FROM Sales INNER JOIN Users ON Sales.UserID = Users.UserID";
            dtSales = myDataservies.RunQuery(sSql);
            //hiển thi lên lưới
            dgvSales.DataSource = dtSales;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            modNew = true;
            txtCustomerName.Clear();
            txtCustomerPhone.Clear();
            txtDescription.Clear();
            txtQuantity.Clear();
            SetControl(true);

            txtCustomerName.Focus();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            modNew = false;
            SetControl(true);
            txtCustomerName.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            SetControl(false);
        }

        private void dgvSaleDetails_RowEnter(object sender, DataGridViewCellEventArgs e)
        {

            cboProductName.SelectedValue = dgvSaleDetails.Rows[e.RowIndex].Cells["Product"].Value.ToString();
            txtQuantity.Text = dgvSaleDetails.Rows[e.RowIndex].Cells["SaleQuantity"].Value.ToString();
            //double sum = 0;
            //for (int i = 0; i < dgvSaleDetails.Rows.Count; ++i)
            //{
                //sum += Convert.ToDouble(dgvSaleDetails.Rows[i].Cells["TotalFunds"].Value);
            //}
            //txtMoney.Text = sum.ToString();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //xác nhận chắc chắn xóa dữ liệu không
            DialogResult dr;
            dr = MessageBox.Show("Chắc chắn xóa dòng đã chọn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No) return;

            //1. lấy dòng đang chọn để xóa
            int r = dgvSales.CurrentRow.Index;
            //2. lấy BookID của dòng đang chọn
            string SaleID = dgvSales.Rows[r].Cells[0].Value.ToString();
            //3. xóa dữ liệu trong bảng Sales
            string sSql = "DELETE FROM SaleDetails WHERE SaleID = '" + SaleID + "' \n DELETE FROM Sales WHERE SaleID = '" + SaleID + "'";
            myDataservies.ExecuteNonQuery(sSql);
            frmSales_Load(null, null);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //1. Kiểm tra dữ liệu
            string UserID = frmLogin.UserID;
            if (txtCustomerName.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập tên khách hàng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCustomerName.Focus();
                return;
            }
            if(txtCustomerPhone.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập số điện thoại khách hàng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCustomerPhone.Focus();
                return;
            }   

            if (modNew == true)
            {
                //thêm mới
                
                string sSQL = "INSERT INTO Sales(UserID,CustomerName,CustomerPhone,SaleDate,Description) VALUES (" + UserID + ",N'" + txtCustomerName.Text + "'," + txtCustomerPhone.Text + ",'" + dtpSaleDate.Value + "',N'" + txtDescription.Text + "')";
                myDataservies.ExecuteNonQuery(sSQL);

                //DataRow newRow = dtSales.NewRow();
                //newRow["UserID"] = cboUserName.SelectedValue;
                //newRow["CustomerName"] = txtCustomerName.Text;
                //newRow["CustomerPhone"] = txtCustomerPhone.Text;
                //newRow["SaleDate"] = dtpSaleDate.Value;
                //newRow["Description"] = txtDescription.Text;
                //dtSales.Rows.Add(newRow);
                //myDataservies.Update(dtSales);
            }
            else
            {
                //sửa
                int r = dgvSales.CurrentRow.Index;
                string SaleID = dgvSales.Rows[r].Cells["SaleID1"].Value.ToString();
                string ssSql = "UPDATE Sales SET CustomerName = N'" + txtCustomerName.Text + "',UserID = " + UserID + ", CustomerPhone = " + txtCustomerPhone.Text + ",SaleDate = '" + dtpSaleDate.Value + "',Description = '" + txtDescription.Text + "' WHERE SaleID = '" + SaleID + "'";
                myDataservies.ExecuteNonQuery(ssSql);
            }
            frmSales_Load(null, null);
            SetControl(false);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (rbCustomerName.Checked == true)
            {
                string sSql = " SELECT SaleID,FullName,CustomerName,CustomerPhone,SaleDate,Sales.Description FROM Sales INNER JOIN Users ON Sales.UserID = Users.UserID WHERE CustomerName = N'" + txtSearch.Text + "'";
                DataTable dtSearch = myDataservies.RunQuery(sSql);
                dgvSales.DataSource = dtSearch;
                
            }
            else
            {
                string sSql = " SELECT SaleID,FullName,CustomerName,CustomerPhone,SaleDate,Sales.Description FROM Sales INNER JOIN Users ON Sales.UserID = Users.UserID WHERE CustomerPhone = " + txtSearch.Text + "";
                DataTable dtSearch = myDataservies.RunQuery(sSql);
                dgvSales.DataSource = dtSearch;
            }
            txtSearch.Clear();
            rbCustomerName.Enabled = true;
            tbPhone.Enabled = true;
        }

        private void rbCustomerName_CheckedChanged(object sender, EventArgs e)
        {
            tbPhone.Enabled = false;
            txtSearch.Focus();
        }

        private void tbPhone_CheckedChanged(object sender, EventArgs e)
        {
            rbCustomerName.Enabled = false;
            txtSearch.Focus();
        }

        private void btnAddSaleDetails_Click(object sender, EventArgs e)
        {
            //1. Kiểm tra dữ liệu
            if (cboProductName.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị chọn tên sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtQuantity.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập số lượng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtQuantity.Focus();
                return;
            }
            if (cboSaleID.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị chọn mã phiếu bán!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            

            if (modNew == true)
            {
                //thêm mới
                //1. Nhập dữ liệu vào bảng SaleDetails
                string sSQL = "INSERT INTO SaleDetails(SaleID,ProductID,SaleQuantity) VALUES ('" + cboSaleID.Text + "','" + cboProductName.SelectedValue + "'," + txtQuantity.Text + ")";
                
                myDataservies.ExecuteNonQuery(sSQL);
            }
            
            disPlaySaleDetails();
        }

        private void disPlaySaleDetails()
        {
            string sSQL = "Select SaleDetails.SaleID, Products.ProductName, SaleDetails.SaleQuantity, Products.Price, (SaleQuantity * Price) AS 'TotalFunds' From Products INNER JOIN SaleDetails ON Products.ProductID = SaleDetails.ProductID Where SaleID='" + cboSaleID.Text + "' \n Group by SaleDetails.SaleID, Products.ProductName, SaleDetails.SaleQuantity, Products.Price ";
            dtSaleDetails = myDataservies.RunQuery(sSQL);
            dgvSaleDetails.AutoGenerateColumns = false;
            dgvSaleDetails.DataSource = dtSaleDetails;
        }

        private void btnToTalPayment_Click(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < dgvSaleDetails.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(dgvSaleDetails.Rows[i].Cells["TotalFunds"].Value);
            }
            txtTotalPayment.Text = sum.ToString();

            int r = dgvSales.CurrentRow.Index;
            string SaleID = dgvSales.Rows[r].Cells["SaleID1"].Value.ToString();

            string sSql = "UPDATE Sales SET TotalPayment =" + txtTotalPayment.Text + "WHERE SaleID = '" + SaleID + "'";
            myDataservies.ExecuteNonQuery(sSql);
            
            MessageBox.Show("Lưu hóa đơn thành công!");

            // Kiểm tra xem có chi tiết hóa đơn để in không
            if (dtSaleDetails.Rows.Count == 0)
            {
                MessageBox.Show("Không có chi tiết hóa đơn để in.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Tạo đối tượng PrintDocument
            string fileName = cboSaleID.SelectedValue.ToString(); // Lấy giá trị SaleID từ combobox
            PrintDocument printDocument = new PrintDocument();
            printDocument.DocumentName = fileName; // Gán tên file in là giá trị của SaleID
            printDocument.PrintPage += new PrintPageEventHandler(PrintDocument_PrintPage);

            // Hiển thị hộp thoại in
            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = printDocument;
            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                printDocument.Print();
            }

            frmSales_Load(null, null);
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            Graphics graphics = e.Graphics;
            Font font = new Font("Roboto Mono", 12);
            Brush brush = Brushes.Black;
            float lineHeight = font.GetHeight();

            // Lấy thông tin khách hàng từ dgvSales
            int selectedCustomerIndex = dgvSales.CurrentRow.Index;
            string customerName = dgvSales.Rows[selectedCustomerIndex].Cells["CustomerName"].Value.ToString();
            string Phone = dgvSales.Rows[selectedCustomerIndex].Cells["CustomerPhone"].Value.ToString();
            string Date = dgvSales.Rows[selectedCustomerIndex].Cells["SaleDate"].Value.ToString();

            // Lấy thông tin hóa đơn từ TextBox và dgvSaleDetails
            string Quantity = txtQuantity.Text;
            decimal totalPayment = Convert.ToDecimal(txtTotalPayment.Text);

            // Vẽ tiêu đề hóa đơn
            float startX = 10;
            float startY = 10;
            graphics.DrawString("HÓA ĐƠN BÁN HÀNG", font, brush, startX, startY);

            // Vẽ thông tin khách hàng
            startY += lineHeight * 2;
            graphics.DrawString($"Khách hàng: {customerName}", font, brush, startX, startY);

            startY += lineHeight;
            graphics.DrawString($"Số điện thoại: {Phone}", font, brush, startX, startY);

            

            // Vẽ thông tin hóa đơn
            startY += lineHeight * 2;
            graphics.DrawString($"Ngày bán: {Date}", font, brush, startX, startY);

            startY += lineHeight;
            graphics.DrawString("-------------------------------", font, brush, startX, startY);

            // Vẽ danh sách sản phẩm và thông tin chi tiết
            startY += lineHeight;
            graphics.DrawString("Sản phẩm", font, brush, startX, startY);
            graphics.DrawString("Đơn giá", font, brush, startX + 200, startY);
            graphics.DrawString("Số lượng", font, brush, startX + 350, startY);
            graphics.DrawString("Thành tiền(Nghìn VND)", font, brush, startX + 500, startY);

            startY += lineHeight;

            for (int i = 0; i < dtSaleDetails.Rows.Count; i++)
            {
                string productName = dtSaleDetails.Rows[i]["ProductName"].ToString();
                decimal Price = Convert.ToDecimal(dtSaleDetails.Rows[i]["Price"]);
                int quantity = Convert.ToInt32(dtSaleDetails.Rows[i]["SaleQuantity"]);
                decimal subtotal = Price * quantity;

                graphics.DrawString(productName, font, brush, startX, startY);
                graphics.DrawString(Price.ToString("N5"), font, brush, startX + 200, startY);
                graphics.DrawString(quantity.ToString(), font, brush, startX + 350, startY);
                graphics.DrawString(subtotal.ToString("N5"), font, brush, startX + 500, startY);

                startY += lineHeight;
            }

            // Vẽ đường kẻ dưới danh sách sản phẩm
            startY += lineHeight;
            graphics.DrawString("-------------------------------", font, brush, startX, startY);

            // Vẽ tổng tiền
            startY += lineHeight * 2;
            graphics.DrawString($"Tổng tiền: {totalPayment.ToString("N5")} nghìn VND", font, brush, startX, startY);

            // Vẽ chữ ký
            startY += lineHeight * 3;
            graphics.DrawString("Người bán hàng", font, brush, startX, startY);

            startY += lineHeight;
            graphics.DrawString(lbUser.Text, font, brush, startX, startY);

            // Hoàn thành trang in
            e.HasMorePages = false;
        }

        private void dtpSaleDate_ValueChanged(object sender, EventArgs e)
        {
            // Lấy thời gian hiện tại
            DateTime currentTime = DateTime.Now;

            // Đặt giá trị thời gian hiện tại lên DateTimePicker
            dtpSaleDate.Value = currentTime;
        }

        private void dgvSales_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            cboSaleID.Text = dgvSales.Rows[e.RowIndex].Cells["SaleID1"].Value.ToString();
            txtCustomerName.Text = dgvSales.Rows[e.RowIndex].Cells["CustomerName"].Value.ToString();
            txtCustomerPhone.Text = dgvSales.Rows[e.RowIndex].Cells["CustomerPhone"].Value.ToString();
            dtpSaleDate.Text = dgvSales.Rows[e.RowIndex].Cells["SaleDate"].Value.ToString();
            txtDescription.Text = dgvSales.Rows[e.RowIndex].Cells["Description"].Value.ToString();

            disPlaySaleDetails();
            string sSql = "Select * from Products";
            DataTable dtProducts = myDataservies.RunQuery(sSql);
            cboProductName.DataSource = dtProducts;
            cboProductName.DisplayMember = "ProductName";
            cboProductName.ValueMember = "ProductID";
        }
    }
}
