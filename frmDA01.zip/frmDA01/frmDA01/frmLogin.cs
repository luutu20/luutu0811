﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmDA01
{
    public partial class frmLogin : Form
    {
        private DataServices myDataServices = new DataServices();
        public static string UserID;
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            //kết nối tới CSDL
            string UserName = txtUserName.Text;
            string Password = txtPassword.Text;

            if (myDataServices.OpenDB())
            {
                //kiểm tra UserName và Password trong bảng Users
                string sSql = "SELECT * FROM Users WHERE (UserName = N'" + UserName + "') and (Password = N'" + Password + "')";
                DataTable dtUser = myDataServices.RunQuery(sSql);

                if (dtUser != null && dtUser.Rows.Count > 0)
                {
                    // Đăng nhập thành công!
                    MessageBox.Show("Đăng nhập thành công!");

                    frmMain frmMain = new frmMain();

                    frmMain.Show();

                    // Mở form frmMain và truyền ID người dùng
                    UserID = dtUser.Rows[0]["UserID"].ToString();


                    // Đóng form đăng nhập
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Sai tên đăng nhập hoặc mật khẩu!");
                }
            }
            else
            {
                MessageBox.Show("Không thể kết nối tới CSDL!");
            }
        }
        private void frmLogin_Load(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                txtPassword.UseSystemPasswordChar = false;
            }
            else
            {
                txtPassword.UseSystemPasswordChar = true;
            }
        }
    }
}
