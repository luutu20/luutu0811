﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmDA01
{
    public partial class frmProducts : Form
    {
        private DataServices myDataServices = new DataServices();
        private DataTable dtProducts;
        private bool modNew;
        private string oldProductName;
        public frmProducts()
        {
            InitializeComponent();
        }

        private void frmProducts_Load(object sender, EventArgs e)
        {
            //kết nối tới CSDL

            myDataServices.OpenDB();

            string sSql;   
            //Đưa dữ liệu lên Combobox TradeMark
            sSql = "Select * From TradeMark";
            DataTable dtTradeMark = myDataServices.RunQuery(sSql);
            cboTradeMark.DataSource = dtTradeMark;
            cboTradeMark.DisplayMember = "TradeMarkName";
            cboTradeMark.ValueMember = "TradeMarkID";

            //Đưa dữ liệu lên Combobox Categories
            sSql = "Select * From Categories";
            DataTable dtCategories = myDataServices.RunQuery(sSql);
            cboCategories.DataSource = dtCategories;
            cboCategories.DisplayMember = "CategoryName";
            cboCategories.ValueMember = "CategoryID";

            //Đưa dữ liệu lên ComboBox ProductMaterial
            sSql = "Select * from ProductMaterials";
            DataTable dtProductMaterials = myDataServices.RunQuery(sSql);
            cboProductMaterial.DataSource = dtProductMaterials;
            cboProductMaterial.DisplayMember = "ProductMaterials";
            cboProductMaterial.ValueMember = "ProductMaterialID";

            //Đưa dữ liệu lên ComboBox Color
            sSql = "Select * from Colors";
            DataTable dtColors = myDataServices.RunQuery(sSql);
            cboColor.DataSource = dtColors;
            cboColor.DisplayMember = "Color";
            cboColor.ValueMember = "ColorID";

            //Đưa dữ liệu lên ComboBox Size
            sSql = "Select * from Size";
            DataTable dtSize = myDataServices.RunQuery(sSql);
            cboSize.DataSource = dtSize;
            cboSize.DisplayMember = "Size";
            cboSize.ValueMember = "SizeID";

            disPlay();
            //thiết lập các điều khiển
            SetControl(false);
        }

        private void disPlay()
        {
            //Đưa dữ liệu lên lưới Datagridview
            string sSql = "SELECT Products.ProductID, Products.ProductName, Categories.CategoryName, TradeMark.TradeMarkName, ProductMaterials.ProductMaterials, Products.Price, Colors.Color, Size.Size, Products.MadeIn, Products.ProductQuantity, Products.Description \nFROM  dbo.Products INNER JOIN \ndbo.ProductMaterials ON dbo.Products.ProductMaterialID = dbo.ProductMaterials.ProductMaterialID \nINNER JOIN dbo.Colors ON dbo.Products.ColorID = dbo.Colors.ColorID \nINNER JOIN dbo.Categories ON dbo.Products.CategoryID = dbo.Categories.CategoryID \nINNER JOIN dbo.Size ON dbo.Products.SizeID = dbo.Size.SizeID \nINNER JOIN dbo.TradeMark ON dbo.Products.TradeMarkID = dbo.TradeMark.TradeMarkID";
            dtProducts = myDataServices.RunQuery(sSql);
            dgvProducts.AutoGenerateColumns = false;
            dgvProducts.DataSource = dtProducts;
        }

        private void SetControl(bool edit)
        {
            txtProductName.Enabled = edit;
            cboCategories.Enabled = edit;
            cboTradeMark.Enabled = edit;
            cboProductMaterial.Enabled = edit;
            txtPrice.Enabled = edit;
            cboColor.Enabled = edit;
            cboSize.Enabled = edit;
            txtMadeIn.Enabled = edit;
            txtDescription.Enabled = edit;
            
            // các btn
            btnAdd.Enabled = !edit;
            btnCancel.Enabled = edit;
            btnDelete.Enabled = !edit;
            btnSave.Enabled = edit;
            btnEdit.Enabled = !edit;
            
        }
        
        private void btnAdd_Click(object sender, EventArgs e)
        {
            modNew = true;
            //xóa các textbox
            txtProductName.Clear();
            txtPrice.Clear();
            txtMadeIn.Clear();
            txtDescription.Clear();
            //chuyển trạng thái các nút
            SetControl(true);
            txtProductName.Focus();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            modNew = false;
            SetControl(true);
            txtProductName.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            SetControl(false);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void rbProductName_CheckedChanged(object sender, EventArgs e)
        {
            tbTradeMarkName.Enabled = false;
            txtSearch.Focus();
        }

        private void tbTradeMarkName_CheckedChanged(object sender, EventArgs e)
        {
            rbProductName.Enabled = false;
            txtSearch.Focus();
        }

        private void dgvProducts_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtProductName.Text = dgvProducts.Rows[e.RowIndex].Cells["ProductName"].Value.ToString();
            cboCategories.Text = dgvProducts.Rows[e.RowIndex].Cells["CategoryName"].Value.ToString();
            cboTradeMark.Text = dgvProducts.Rows[e.RowIndex].Cells["TradeMarkName"].Value.ToString();
            cboProductMaterial.Text = dgvProducts.Rows[e.RowIndex].Cells["ProductMaterials"].Value.ToString();
            txtPrice.Text = dgvProducts.Rows[e.RowIndex].Cells["Price"].Value.ToString();
            cboColor.Text = dgvProducts.Rows[e.RowIndex].Cells["Color"].Value.ToString();
            cboSize.Text = dgvProducts.Rows[e.RowIndex].Cells["Size"].Value.ToString();
            txtMadeIn.Text = dgvProducts.Rows[e.RowIndex].Cells["MadeIn"].Value.ToString();
            txtDescription.Text = dgvProducts.Rows[e.RowIndex].Cells["Description"].Value.ToString();
        }

        private void mnuTradeMark_Click(object sender, EventArgs e)
        {
            frmTradeMark frmTradeMark = new frmTradeMark();
            frmTradeMark.ShowDialog();
        }

        private void mnuNhapHang_Click(object sender, EventArgs e)
        {
            frmCategories frmCategories = new frmCategories();
            frmCategories.ShowDialog();
        }

        private void mnuColor_Click(object sender, EventArgs e)
        {
            frmColor frmColor = new frmColor();
            frmColor.ShowDialog();
        }

        

        private void btnSave_Click(object sender, EventArgs e)
        {
            //1. Kiểm tra dữ liệu
            if (txtProductName.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập tên sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtProductName.Focus();
                return;
            }

            if (txtPrice.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập giá sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtPrice.Focus();
                return;
            }
            if (txtMadeIn.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập xuất xứ sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMadeIn.Focus();
                return;
            }
            //Kiểm tra tiếp những textbox khác
            //...

            if (modNew == true)
            {
                //thêm mới
                //1. Nhập dữ liệu vào bảng Products
                string sSQL = "INSERT INTO Products(ProductName,CategoryID,TradeMarkID,ProductMaterialID,ColorID,SizeID,MadeIn,Price,Description) VALUES (N'" + txtProductName.Text + "','" + cboCategories.SelectedValue + "','" + cboTradeMark.SelectedValue + "','" + cboProductMaterial.SelectedValue + "','" + cboColor.SelectedValue + "','" + cboSize.SelectedValue + "',N'" + txtMadeIn.Text + "'," + txtPrice.Text + ",N'" + txtDescription.Text + "')";
                myDataServices.ExecuteNonQuery(sSQL);
                
            }
            else
            {
                //sửa
                int r = dgvProducts.CurrentRow.Index;
                string ProductID = dgvProducts.Rows[r].Cells["ProductID"].Value.ToString();
                string ssSql = "UPDATE Products SET ProductName = N'" + txtProductName.Text + "',CategoryID = '" + cboCategories.SelectedValue + "',TradeMarkID = '" + cboTradeMark.SelectedValue + "',ProductMaterialID = '" + cboProductMaterial.SelectedValue + "',ColorID = '" + cboColor.SelectedValue + "',SizeID = '" + cboSize.SelectedValue + "', MadeIn = '" + txtMadeIn.Text + "',Price = '" + txtPrice.Text + "',Description = '" + txtDescription.Text + "' WHERE ProductID = '" + ProductID + "'";
                myDataServices.ExecuteNonQuery(ssSql);
            }
            frmProducts_Load(null,null);
            SetControl(false);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //xác nhận chắc chắn xóa dữ liệu không
            DialogResult dr;
            dr = MessageBox.Show("Chắc chắn xóa dòng đã chọn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No) return;

            //1. lấy dòng đang chọn để xóa
            int r = dgvProducts.CurrentRow.Index;
            //2. lấy ProductID của dòng đang chọn
            string ProductID = dgvProducts.Rows[r].Cells[0].Value.ToString();           
            //3. xóa dữ liệu trong bảng Products
            dtProducts.Rows[r].Delete();
            string sSql = "Delete From Products WHERE ProductID = '" + ProductID + "'";
            myDataServices.ExecuteNonQuery(sSql);
            //cập nhật lại bảng
            //myDataServices.Update(dtProducts);
            frmProducts_Load(null, null);
        }

        private void mnuProductMaterial_Click(object sender, EventArgs e)
        {
            frmProductMaterial frmProductMaterial = new frmProductMaterial();
            frmProductMaterial.ShowDialog();
        }

        private void mnuSize_Click(object sender, EventArgs e)
        {
            frmSize frmSize = new frmSize();    
            frmSize.ShowDialog();   
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (rbProductName.Checked == true)
            {
                string sSql = "SELECT Products.ProductID, Products.ProductName, Categories.CategoryName, TradeMark.TradeMarkName, ProductMaterials.ProductMaterials, Products.Price, Colors.Color, Size.Size, Products.MadeIn,Products.Description \n FROM Products INNER JOIN ProductMaterials ON Products.ProductMaterialID = ProductMaterials.ProductMaterialID \n INNER JOIN Colors ON Products.ColorID = Colors.ColorID \n INNER JOIN Categories ON Products.CategoryID = Categories.CategoryID \n INNER JOIN Size ON Products.SizeID = Size.SizeID \n INNER JOIN TradeMark ON Products.TradeMarkID = TradeMark.TradeMarkID \n WHERE ProductName LIKE N'%" + txtSearch.Text + "%'";
                DataTable dtSearch = myDataServices.RunQuery(sSql);
                dgvProducts.DataSource = dtSearch;

            }
            else 
            {                
                string sSql = "SELECT Products.ProductID, Products.ProductName, Categories.CategoryName, TradeMark.TradeMarkName, ProductMaterials.ProductMaterials, Products.Price, Colors.Color, Size.Size, Products.MadeIn,Products.Description \n FROM Products INNER JOIN ProductMaterials ON Products.ProductMaterialID = ProductMaterials.ProductMaterialID \n INNER JOIN Colors ON Products.ColorID = Colors.ColorID \n INNER JOIN Categories ON Products.CategoryID = Categories.CategoryID \n INNER JOIN Size ON Products.SizeID = Size.SizeID \n INNER JOIN TradeMark ON Products.TradeMarkID = TradeMark.TradeMarkID \n WHERE TradeMarkName LIKE N'%" + txtSearch.Text + "%'";
                DataTable dtSearch = myDataServices.RunQuery(sSql);
                dgvProducts.DataSource = dtSearch;
            }
            txtSearch.Clear();
            rbProductName.Enabled = true;
            tbTradeMarkName.Enabled = true;
        }
    }
    
}
