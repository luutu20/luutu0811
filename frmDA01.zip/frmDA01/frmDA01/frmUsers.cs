﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmDA01
{
    public partial class frmUsers : Form
    {
        private DataServices userDataservices = new DataServices();
        private DataTable dtUsers;
        private bool modeNew;
        private string oldUserName;
        public frmUsers()
        {
            InitializeComponent();
        }

        private void setControl(bool edit)
        {
            //đặt trạng thái các textBox
            txtFullName.Enabled = edit;
            txtUserName.Enabled = edit;
            txtPassword.Enabled = edit;
            txtPhone.Enabled = edit;
            txtEmail.Enabled = edit;
            txtIdentification.Enabled = edit;
            txtDescription.Enabled = edit;
            txtAddress.Enabled = edit;
            dtpUserDate.Enabled = edit;

            //đặt trạng thái các nút ấn
            btnAdd.Enabled = !edit;
            btnEdit.Enabled = !edit;
            btnDelete.Enabled = !edit;
            btnSave.Enabled = edit;
            btnCancel.Enabled = edit;
        }

        private void disPlay()
        {
            string sSql = "SELECT * FROM Users ORDER BY FullName";
            dtUsers = userDataservices.RunQuery(sSql);
            dgvUsers.DataSource = dtUsers;
        }
        private void frmUsers_Load(object sender, EventArgs e)
        {
            userDataservices.OpenDB();

            disPlay();
            setControl(false);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            modeNew = true;
            setControl(true);
            //xóa trắng các textbox
            txtFullName.Clear();
            txtUserName.Clear();
            txtPassword.Clear();
            txtPhone.Clear();
            txtEmail.Clear();
            txtAddress.Clear();
            txtDescription.Clear();
            txtIdentification.Clear();
            //chuyển con trỏ về txtFullName
            txtFullName.Focus();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            modeNew = false;
            setControl(true);
            txtFullName.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            setControl(false);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //xác nhận chắc chắn xóa dữ liệu không
            DialogResult dr; //tạo biến lưu trữ kết quả của một đoạn hội thoại
            dr = MessageBox.Show("Chắc chắn xóa dòng đã chọn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No) return;

            //1. lấy dòng đang chọn để xóa
            int r = dgvUsers.CurrentRow.Index;
            //2. xóa dòng tương ứng với r trong dtUsers
            dtUsers.Rows[r].Delete();
            //3. Cập nhật lại bảng Users trong CSDL
            userDataservices.Update(dtUsers);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string sSql;
            //kiểm tra dữ liệu trùng
            if ((modeNew == true) || ((modeNew == false) && (txtUserName.Text.ToUpper() != oldUserName.ToUpper())))
            {
                //truy vấn dữ liệu để kiểm tra trùng
                sSql = "SELECT UserName from Users WHERE UserName = N'" + txtUserName.Text + "'";
                DataServices myDataServices1 = new DataServices();
                DataTable dtSearch = myDataServices1.RunQuery(sSql);
                if (dtSearch.Rows.Count > 0)
                {
                    MessageBox.Show("Đã trùng tài khoản đăng nhập!", "Thông báo", MessageBoxButtons.OK);
                    txtUserName.Focus();
                    return;
                }
            }

            //thêm mới hoặc sửa
            if (modeNew == true)
            {
                //thêm mới dữ liệu
                DataRow addRow = dtUsers.NewRow();
                addRow["FullName"] = txtFullName.Text;
                addRow["UserName"] = txtUserName.Text;
                addRow["Password"] = txtPassword.Text;
                addRow["Phone"] = txtPhone.Text;
                addRow["Email"] = txtEmail.Text;
                addRow["Identification"] = txtIdentification.Text;
                addRow["Address"] = txtAddress.Text;
                addRow["Birthday"] = dtpUserDate.Value;
                addRow["Description"] = txtDescription.Text;
                dtUsers.Rows.Add(addRow);
                userDataservices.Update(dtUsers);
            }
            else
            {
                //sửa dữ liệu
                //lấy dòng cần sửa
                int r = dgvUsers.CurrentRow.Index;
                DataRow editRow = dtUsers.Rows[r];
                editRow["FullName"] = txtFullName.Text;
                editRow["UserName"] = txtUserName.Text;
                editRow["Password"] = txtPassword.Text;
                editRow["Phone"] = txtPhone.Text;
                editRow["Email"] = txtEmail.Text;
                editRow["Identification"] = txtIdentification.Text;
                editRow["Address"] = txtAddress.Text;
                editRow["Birthday"] = dtpUserDate.Value;
                editRow["Description"] = txtDescription.Text;
                userDataservices.Update(dtUsers);
            }
            //Hiển thị lại dữ liệu           
            disPlay();
            //thiết lập lại trạng thái
            setControl(false);
        }

        private void dgvUsers_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtUserName.Text = dgvUsers.Rows[e.RowIndex].Cells["UserName"].Value.ToString();
            txtPassword.Text = dgvUsers.Rows[e.RowIndex].Cells["Password"].Value.ToString();
            txtFullName.Text = dgvUsers.Rows[e.RowIndex].Cells["FullName"].Value.ToString();
            txtAddress.Text = dgvUsers.Rows[e.RowIndex].Cells["Address"].Value.ToString();
            txtIdentification.Text = dgvUsers.Rows[e.RowIndex].Cells["Identification"].Value.ToString();
            txtPhone.Text = dgvUsers.Rows[e.RowIndex].Cells["Phone"].Value.ToString();
            txtEmail.Text = dgvUsers.Rows[e.RowIndex].Cells["Email"].Value.ToString();
            dtpUserDate.Text = dgvUsers.Rows[e.RowIndex].Cells["Birthday"].Value.ToString();
            txtDescription.Text = dgvUsers.Rows[e.RowIndex].Cells["Description"].Value.ToString();

            oldUserName = txtUserName.Text;
        }

        private void rbUserName_CheckedChanged(object sender, EventArgs e)
        {
            tbAddress.Enabled = false;
            txtSearch.Focus();
        }

        private void tbPhone_CheckedChanged(object sender, EventArgs e)
        {
            rbUserName.Enabled = false;
            txtSearch.Focus();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (rbUserName.Checked == true)
            {
                string sSql = "SELECT * FROM Users WHERE UserName LIKE N'%" + txtSearch.Text + "%'";
                DataTable dtSearch = userDataservices.RunQuery(sSql);
                dgvUsers.DataSource = dtSearch;

            }
            else
            {
                string sSql = "SELECT * FROM Users WHERE Address LIKE N'%" + txtSearch.Text + "%'";
                DataTable dtSearch = userDataservices.RunQuery(sSql);
                dgvUsers.DataSource = dtSearch;
            }
            txtSearch.Clear();
            rbUserName.Checked = false;
            tbAddress.Checked = false;
            rbUserName.Enabled = true;
            tbAddress.Enabled = true;
        }
    }
}
