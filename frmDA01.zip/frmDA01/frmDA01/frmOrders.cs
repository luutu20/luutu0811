﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmDA01
{
    public partial class frmOrders : Form
    {
        private DataServices odDataServices = new DataServices();
        private DataTable dtOrders, dtOrderDetails;
        private bool modeNew;
        public frmOrders()
        {
            InitializeComponent();
        }

        private void frmOrders_Load(object sender, EventArgs e)
        {
            odDataServices.OpenDB();

            string sSql = " SELECT * FROM Suppliers";
            DataTable dtSuppliers = odDataServices.RunQuery(sSql);
            cboSupplier.DataSource = dtSuppliers;
            cboSupplier.ValueMember = "SupplierID";
            cboSupplier.DisplayMember = "SupplierName";

            //Đưa dữ liệu lên ComboBox ProductName
            sSql = "Select * from Products order by ProductName";
            DataTable dtProducts = odDataServices.RunQuery(sSql);
            cboProduct.DataSource = dtProducts;
            cboProduct.DisplayMember = "ProductName";
            cboProduct.ValueMember = "ProductID";

            // Lấy thời gian hiện tại
            //DateTime currentTime = DateTime.Now;
            // Đặt giá trị thời gian hiện tại lên DateTimePicker
            //dtpOrderdate.Value = currentTime;

            string UserID = frmLogin.UserID;

            sSql = "SELECT FullName FROM Users WHERE UserID = " + UserID + "";
            DataTable result = odDataServices.RunQuery(sSql);
            if (result.Rows.Count > 0)
            {
                // Giả sử cột FullName trong result chứa giá trị bạn muốn hiển thị
                string fullName = result.Rows[0]["FullName"].ToString();
                lbUser.Text = fullName;
            }

            disPlay();
            setControl(false);
        }

        private void disPlay()
        {
            string sSql = "SELECT OrderID, Users.FullName, Suppliers.SupplierName, OrderDate, Orders.Description FROM Suppliers INNER JOIN Orders ON Orders.SupplierID = Suppliers.SupplierID \n INNER JOIN Users ON Users.UserID = Orders.UserID";
            dtOrders = odDataServices.RunQuery(sSql);
            dgvOrders.DataSource = dtOrders;
        }

        private void dgvOrders_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            cboSupplier.Text = dgvOrders.Rows[e.RowIndex].Cells["Supplier"].Value.ToString();
            lbUser.Text = dgvOrders.Rows[e.RowIndex].Cells["User"].Value.ToString();
            dtpOrderdate.Text = dgvOrders.Rows[e.RowIndex].Cells["OrderDate"].Value.ToString();
            txtDescription.Text = dgvOrders.Rows[e.RowIndex].Cells["Description"].Value.ToString();
            cboOrderID.Text = dgvOrders.Rows[e.RowIndex].Cells["OrderID"].Value.ToString();

            disPlayDetails();
            //Đưa dữ liệu lên ComboBox ProductName
            string sSql = "Select * from Products order by ProductName";
            DataTable dtProducts = odDataServices.RunQuery(sSql);
            cboProduct.DataSource = dtProducts;
            cboProduct.DisplayMember = "ProductName";
            cboProduct.ValueMember = "ProductID";
        }

        private void disPlayDetails()
        {
            string sSql = "SELECT OrderDetails.OrderID, Products.ProductName, OrderQuantity \nFROM Products INNER JOIN OrderDetails ON Products.ProductID = OrderDetails.ProductID \nWHERE OrderID ='" + cboOrderID.Text + "'";
            dtOrderDetails = odDataServices.RunQuery(sSql);
            dgvOrderDetails.DataSource = dtOrderDetails;
        }

        private void btnSuppliers_Click(object sender, EventArgs e)
        {
            frmSuppliers frmSuppliers = new frmSuppliers();
            frmSuppliers.ShowDialog();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            modeNew = true;
            txtDescription.Clear();           
            setControl(true);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            modeNew = false;
            setControl(true);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            setControl(false);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //1. hỏi xác nhận xóa dữ liệu không?
            DialogResult dr;
            dr = MessageBox.Show("Chắc chắn xóa dòng đang chọn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No) return;

            //2. lấy dòng con trỏ đang chọn trên lưới -> dòng cần xóa
            int r = dgvOrders.CurrentRow.Index;

            string OrderID = dgvOrders.Rows[r].Cells[0].Value.ToString();
            //3. xóa dữ liệu trong bảng Orders
            string sSql = "DELETE FROM Orders WHERE OrderID = '" + OrderID + "'";
            odDataServices.ExecuteNonQuery(sSql);
            disPlay();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string UserID = frmLogin.UserID;
            //thêm mới hoặc sửa
            if (modeNew == true)
            {
                //thêm mới dữ liệu
                string sSql = "INSERT INTO Orders(UserID,SupplierID,OrderDate,Description) VALUES(" + UserID + ",'" + cboSupplier.SelectedValue + "','" + dtpOrderdate.Value + "','" + txtDescription.Text + "')";
                odDataServices.ExecuteNonQuery(sSql);
                
            }
            else
            {
                //sửa dữ liệu
                //1. lấy dòng cần sửa
                int r = dgvOrders.CurrentRow.Index;

                string OrderID = dgvOrders.Rows[r].Cells["OrderID"].Value.ToString();

                string sSql = "UPDATE Orders SET UserID = " + UserID + ", SupplierID = '" + cboSupplier.SelectedValue + "', OrderDate ='" + dtpOrderdate.Value + "', Description = N'" + txtDescription.Text + "' \n WHERE OrderID = '" + OrderID + "'";
                odDataServices.ExecuteNonQuery(sSql);
                
            }
            disPlay();
            setControl(false);
        }

        private void dgvOrderDetails_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            cboProduct.Text = dgvOrderDetails.Rows[e.RowIndex].Cells["Product"].Value.ToString();
            txtOrderQuantity.Text = dgvOrderDetails.Rows[e.RowIndex].Cells["OrderQuantity"].Value.ToString();
        }

        private void btnAddDetails_Click(object sender, EventArgs e)
        {
            //1. Kiểm tra dữ liệu
            if (cboProduct.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị chọn tên sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtOrderQuantity.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập số lượng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtOrderQuantity.Focus();
                return;
            }
            if (cboOrderID.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị chọn mã phiếu nhập!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            if (modeNew == true)
            {
                //thêm mới
                //1. Nhập dữ liệu vào bảng SaleDetails
                string sSQL = "INSERT INTO OrderDetails(OrderID,ProductID,OrderQuantity) VALUES ('" + cboOrderID.Text + "','" + cboProduct.SelectedValue + "'," + txtOrderQuantity.Text + ")";
                
                odDataServices.ExecuteNonQuery(sSQL);
            }

            disPlayDetails();
        }

        private void tbOrderID_CheckedChanged(object sender, EventArgs e)
        {
            rbOrderdate.Enabled = false;
            rbUser.Enabled = false;
            txtSearch.Focus();
        }

        private void rbOrderdate_CheckedChanged(object sender, EventArgs e)
        {
            tbOrderID.Enabled = false;
            rbUser.Enabled = false;
            txtSearch.Focus();
        }

        private void rbUser_CheckedChanged(object sender, EventArgs e)
        {
            rbOrderdate.Enabled = false;
            tbOrderID.Enabled = false;
            txtSearch.Focus();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (tbOrderID.Checked == true)
            {
                string sSql = "SELECT OrderID, Users.FullName, Suppliers.SupplierName, OrderDate, Orders.Description FROM Suppliers INNER JOIN Orders ON Orders.SupplierID = Suppliers.SupplierID \n INNER JOIN Users ON Users.UserID = Orders.UserID WHERE OrderID LIKE '%" + txtSearch.Text + "%'";
                DataTable dtSearch = odDataServices.RunQuery(sSql);
                dgvOrders.DataSource = dtSearch;

            }
            else if (rbUser.Checked == true)
            {
                string sSql = "SELECT OrderID, Users.FullName, Suppliers.SupplierName, OrderDate, Orders.Description FROM Suppliers INNER JOIN Orders ON Orders.SupplierID = Suppliers.SupplierID \n INNER JOIN Users ON Users.UserID = Orders.UserID WHERE FullName LIKE N'%" + txtSearch.Text + "%'";
                DataTable dtSearch = odDataServices.RunQuery(sSql);
                dgvOrders.DataSource = dtSearch;
            }
            else
            {
                string OrderDate = txtSearch.Text;
                DateTime date = DateTime.ParseExact(OrderDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                int day = date.Day;
                int month = date.Month;
                int year = date.Year;
                string sSql = "SELECT OrderID, Users.FullName, Suppliers.SupplierName, OrderDate, Orders.Description FROM Suppliers INNER JOIN Orders ON Orders.SupplierID = Suppliers.SupplierID \n INNER JOIN Users ON Users.UserID = Orders.UserID WHERE DAY(OrderDate) =" + day + " AND MONTH(OrderDate) =" + month + " AND YEAR(OrderDate) =" + year + ";";
                dtOrders = odDataServices.RunQuery(sSql);
                dgvOrders.DataSource = dtOrders;
            }
            txtSearch.Clear();
            rbUser.Enabled = true;
            tbOrderID.Enabled = true;
            rbOrderdate.Enabled = true;
        }

        private void setControl(bool edit)
        {
            cboSupplier.Enabled = edit;
            txtDescription.Enabled = edit;
            dtpOrderdate.Enabled = edit;

            btnAdd.Enabled = !edit;
            btnEdit.Enabled = !edit;
            btnSave.Enabled = edit;
            btnCancel.Enabled = edit;
            btnDelete.Enabled = !edit;
        }
    }

}
