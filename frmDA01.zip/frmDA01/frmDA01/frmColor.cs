﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmDA01
{
    public partial class frmColor : Form
    {
        private DataServices myDataservies;
        private DataTable dtColors;
        private bool modnew;
        private string oldColor;
        public frmColor()
        {
            InitializeComponent();
        }

        private void frmColor_Load(object sender, EventArgs e)
        {
            myDataservies = new DataServices();
            if (myDataservies.OpenDB() == false) return;
            //lấy dữ liệu lên view

            display();
            SetControl(false);
        }
        private void SetControl(bool edit)
        {
            txtColor.Enabled = edit;
            txtDescription.Enabled = edit;

            btnAdd.Enabled = !edit;
            btnEdit.Enabled = !edit;
            btnDelete.Enabled = !edit;
            btnCancel.Enabled = edit;
            btnSave.Enabled = edit;
        }

        private void display()
        {
            string sSql = "SELECT * FROM Colors ORDER BY Color";
            dtColors = myDataservies.RunQuery(sSql);
            dgvColor.AutoGenerateColumns = false;
            dgvColor.DataSource = dtColors;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            modnew = true;
            SetControl(true);

            txtColor.Clear();
            txtDescription.Clear();

            txtColor.Focus();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            modnew = false;
            SetControl(true);
            txtColor.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            SetControl(false);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtColor.Text.Trim() == "")
            {
                MessageBox.Show("Nhập màu sản phẩm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtColor.Focus();
                return;
            }
            //kiểm tra trùng TradeMarkName
            if ((modnew == true) || (modnew == false) && (txtColor.Text.Trim() != oldColor.Trim()))
            {
                string sSql = "SELECT Color FROM Colors WHERE Color = N'" + txtColor.Text + "'";
                DataServices myDataservies = new DataServices();
                DataTable dtSearch = myDataservies.RunQuery(sSql);
                if (dtSearch.Rows.Count > 0)
                {
                    MessageBox.Show("Đã nhập/sửa trùng loại sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtColor.Focus();
                    return;
                }

                if (modnew == true)
                {
                    //thêm dữ liệu
                    string ssSql = "INSERT INTO Colors(Color,Description) VALUES (N'" + txtColor.Text + "',N'" + txtDescription.Text + "')";
                    myDataservies.ExecuteNonQuery(ssSql);
                }
                else
                {
                    //sửa dữ liệu
                    //lấy dòng cần sửa
                    int r = dgvColor.CurrentRow.Index;
                    //Lấy mã ID cần sửa
                    string ColorID = dgvColor.Rows[r].Cells[0].Value.ToString();
                    //Lệnh sửa
                    string ssSql = "UPDATE Colors SET Color = N'" + txtColor.Text + "',Description = N'" + txtDescription.Text + "' WHERE ColorID = '" + ColorID + "'";
                    myDataservies.ExecuteNonQuery(ssSql);
                }
                display();

                SetControl(false);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //xác nhận xóa dữ liệu không
            DialogResult dr;
            dr = MessageBox.Show("Chắc chắn xóa dòng đã chọn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No) return;

            //xóa dữ liệu
            //1. Lấy dòng dữ liệu muốn xóa
            int r = dgvColor.CurrentRow.Index;
            //2.Lấy TradeMarkID
            string ColorID = dgvColor.Rows[r].Cells[0].Value.ToString();
            //Câu lệnh xóa
            string sSql = "DELETE FROM Colors WHERE ColorID = '" + ColorID + "'";
            //Xóa
            myDataservies.ExecuteNonQuery(sSql);
            //hiện thị lại
            display();
        }

        private void dgvColor_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtColor.Text = dgvColor.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtDescription.Text = dgvColor.Rows[e.RowIndex].Cells[2].Value.ToString();

            oldColor = txtColor.Text;
        }
    }
}
