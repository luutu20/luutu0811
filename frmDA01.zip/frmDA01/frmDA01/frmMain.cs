﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmDA01
{
    public partial class frmMain : Form
    {
        private DataServices myDataServices = new DataServices();

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void mnuProducts_Click(object sender, EventArgs e)
        {
            
            frmProducts frmProducts = new frmProducts();
            OpenFormOnPanel(frmProducts);
        }

        private void mnuUser_Click(object sender, EventArgs e)
        {
            
            // Kiểm tra vai trò của người dùng
            string sSql = "SELECT Description FROM Users WHERE UserID = N'" + frmLogin.UserID + "'";

            DataTable result = myDataServices.RunQuery(sSql);

            if (result != null && result.Rows.Count > 0)
            {
                string Description = result.Rows[0]["Description"].ToString();
                if (Description == "Admin")
                {
                    
                    frmUsers frmUsers = new frmUsers();
                    OpenFormOnPanel(frmUsers);
                }
                else
                {
                    MessageBox.Show("Bạn không có quyền truy cập vào mục này.", "Thông báo");
                }
            }
            else
            {
                MessageBox.Show("Không thể xác định vai trò của người dùng.", "Lỗi");
            }
    
        }

        private void mnuOrder_Click(object sender, EventArgs e)
        {
            frmOrders frmOrders = new frmOrders();
            frmOrders.ShowDialog();
        }

        private void mnuSales_Click(object sender, EventArgs e)
        {
            frmSales frmSales = new frmSales();
            frmSales.ShowDialog();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dateTime = DateTime.Now;
            this.lbTime.Text = dateTime.ToString();
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            
            frmProducts frmProducts = new frmProducts();
            OpenFormOnPanel(frmProducts);
        }

        private void btnUsers_Click(object sender, EventArgs e)
        {
            // Kiểm tra vai trò của người dùng
            string sSql = "SELECT Description FROM Users WHERE UserID = N'" + frmLogin.UserID + "'";

            DataTable result = myDataServices.RunQuery(sSql);

            if (result != null && result.Rows.Count > 0)
            {
                string Description = result.Rows[0]["Description"].ToString();
                if (Description == "Admin")
                {
                    
                    frmUsers frmUsers = new frmUsers();
                    OpenFormOnPanel(frmUsers);                   
                }
                else
                {
                    MessageBox.Show("Bạn không có quyền truy cập vào mục này.", "Thông báo");
                }
            }
            else
            {
                MessageBox.Show("Không thể xác định vai trò của người dùng.", "Lỗi");
            }
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            frmOrders frmOrders = new frmOrders();
            frmOrders.ShowDialog();
        }

        private void btnSales_Click(object sender, EventArgs e)
        {
            frmSales frmSales = new frmSales();
            frmSales.ShowDialog();
        }

        private void OpenFormOnPanel(Form form)
        {
            // Ẩn và giải phóng form hiện tại trên panel (nếu có)
            if (panel1.Controls.Count > 0)
            {
                Form currentForm = panel1.Controls[0] as Form;
                currentForm.Hide();
                currentForm.Dispose();
            }

            // Tạo và hiển thị form mới trên panel
            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.Fill;
            panel1.Controls.Add(form);
            form.Show();
        }

        private void lbStatistics_Click(object sender, EventArgs e)
        {

        }

        private void lbSales_Click(object sender, EventArgs e)
        {

        }

        private void lbOrders_Click(object sender, EventArgs e)
        {

        }

        private void lbUsers_Click(object sender, EventArgs e)
        {

        }

        private void lbProducts_Click(object sender, EventArgs e)
        {

        }

        private void btnStatistics_Click(object sender, EventArgs e)
        {

        }
    }
}
