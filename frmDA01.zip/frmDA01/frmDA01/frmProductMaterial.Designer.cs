﻿namespace frmDA01
{
    partial class frmProductMaterial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvProductMaterials = new System.Windows.Forms.DataGridView();
            this.ProductMaterialID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductMaterials = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtProductMaterial = new System.Windows.Forms.TextBox();
            this.lbDescription = new System.Windows.Forms.Label();
            this.lbProductMaterial = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductMaterials)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvProductMaterials
            // 
            this.dgvProductMaterials.AllowUserToAddRows = false;
            this.dgvProductMaterials.AllowUserToDeleteRows = false;
            this.dgvProductMaterials.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductMaterials.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductMaterialID,
            this.ProductMaterials,
            this.Description});
            this.dgvProductMaterials.Location = new System.Drawing.Point(426, 20);
            this.dgvProductMaterials.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.dgvProductMaterials.Name = "dgvProductMaterials";
            this.dgvProductMaterials.Size = new System.Drawing.Size(517, 257);
            this.dgvProductMaterials.TabIndex = 149;
            this.dgvProductMaterials.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProductMaterials_RowEnter);
            // 
            // ProductMaterialID
            // 
            this.ProductMaterialID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ProductMaterialID.DataPropertyName = "ProductMaterialID";
            this.ProductMaterialID.HeaderText = "ProductMaterialID";
            this.ProductMaterialID.Name = "ProductMaterialID";
            // 
            // ProductMaterials
            // 
            this.ProductMaterials.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ProductMaterials.DataPropertyName = "ProductMaterials";
            this.ProductMaterials.HeaderText = "Chất liệu sản phẩm";
            this.ProductMaterials.Name = "ProductMaterials";
            // 
            // Description
            // 
            this.Description.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Description.DataPropertyName = "Description";
            this.Description.HeaderText = "Mô tả";
            this.Description.Name = "Description";
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(167, 61);
            this.txtDescription.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(221, 23);
            this.txtDescription.TabIndex = 140;
            // 
            // txtProductMaterial
            // 
            this.txtProductMaterial.Location = new System.Drawing.Point(167, 20);
            this.txtProductMaterial.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.txtProductMaterial.Name = "txtProductMaterial";
            this.txtProductMaterial.Size = new System.Drawing.Size(221, 23);
            this.txtProductMaterial.TabIndex = 139;
            // 
            // lbDescription
            // 
            this.lbDescription.AutoSize = true;
            this.lbDescription.Location = new System.Drawing.Point(31, 66);
            this.lbDescription.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbDescription.Name = "lbDescription";
            this.lbDescription.Size = new System.Drawing.Size(41, 15);
            this.lbDescription.TabIndex = 148;
            this.lbDescription.Text = "Mô tả:";
            // 
            // lbProductMaterial
            // 
            this.lbProductMaterial.AutoSize = true;
            this.lbProductMaterial.Location = new System.Drawing.Point(31, 24);
            this.lbProductMaterial.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbProductMaterial.Name = "lbProductMaterial";
            this.lbProductMaterial.Size = new System.Drawing.Size(125, 15);
            this.lbProductMaterial.TabIndex = 147;
            this.lbProductMaterial.Text = "Chất liệu sản phẩm(*):";
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(262, 235);
            this.btnClose.Margin = new System.Windows.Forms.Padding(2);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(84, 42);
            this.btnClose.TabIndex = 146;
            this.btnClose.Text = "Thoát";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(262, 172);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(84, 42);
            this.btnDelete.TabIndex = 143;
            this.btnDelete.Text = "Xóa";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(30, 235);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(84, 42);
            this.btnSave.TabIndex = 144;
            this.btnSave.Text = "Ghi";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(30, 172);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(84, 42);
            this.btnAdd.TabIndex = 141;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(141, 235);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(84, 42);
            this.btnCancel.TabIndex = 145;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(141, 172);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(2);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(84, 42);
            this.btnEdit.TabIndex = 142;
            this.btnEdit.Text = "Sửa";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // frmProductMaterial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(975, 315);
            this.Controls.Add(this.dgvProductMaterials);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.txtProductMaterial);
            this.Controls.Add(this.lbDescription);
            this.Controls.Add(this.lbProductMaterial);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnEdit);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "frmProductMaterial";
            this.Text = "Chất liệu sản phẩm";
            this.Load += new System.EventHandler(this.frmProductMaterial_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductMaterials)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvProductMaterials;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtProductMaterial;
        private System.Windows.Forms.Label lbDescription;
        private System.Windows.Forms.Label lbProductMaterial;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductMaterialID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductMaterials;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
    }
}