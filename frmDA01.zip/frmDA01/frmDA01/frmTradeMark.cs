﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmDA01
{
    public partial class frmTradeMark : Form
    {
        private DataServices myDataServies;
        private DataTable dtTradeMark;
        private bool modNew;
        private string oldTradeMarkName;

        public frmTradeMark()
        {
            InitializeComponent();
        }

        private void frmTradeMark_Load(object sender, EventArgs e)
        {

            myDataServies = new DataServices();
            if (myDataServies.OpenDB() == false) return;

            // đưa dữ liệu lên DataGridView
            display();

            SetControl(false);
            
        }
        private void display()
        {
            string sSql = "SELECT * FROM TradeMark ORDER BY TradeMarkName";
            dtTradeMark = myDataServies.RunQuery(sSql);
            dgvTradeMark.AutoGenerateColumns = false;
            dgvTradeMark.DataSource = dtTradeMark;
        }

        private void SetControl(bool edit)
        {
            //ẩn các textbox
            txtTradeMarkName.Enabled = edit;
            txtDescription.Enabled = edit;

            //ẩn các button
            btnAdd.Enabled = !edit;
            btnEdit.Enabled = !edit;
            btnDelete.Enabled = !edit;
            btnSave.Enabled = edit;
            btnCancel.Enabled = edit;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            modNew = true;
            SetControl(true);

            txtTradeMarkName.Clear();
            txtDescription.Clear();

            txtTradeMarkName.Focus();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            modNew = false;
            SetControl(true);
            txtTradeMarkName.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            SetControl(false);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dgvTradeMark_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtTradeMarkName.Text = dgvTradeMark.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtDescription.Text = dgvTradeMark.Rows[e.RowIndex].Cells[2].Value.ToString();

            oldTradeMarkName = txtTradeMarkName.Text;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //xác nhận xóa dữ liệu không
            DialogResult dr;
            dr = MessageBox.Show("Chắc chắn xóa dòng đã chọn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No) return;

            //xóa dữ liệu
            //1. Lấy dòng dữ liệu muốn xóa
            int r = dgvTradeMark.CurrentRow.Index;
            //2.Lấy TradeMarkID
            string TradeMarkID = dgvTradeMark.Rows[r].Cells[0].Value.ToString();
            //Câu lệnh xóa
            string sSql = "DELETE FROM TradeMark WHERE TradeMarkID = '" + TradeMarkID +"'";
            //Xóa
            myDataServies.ExecuteNonQuery(sSql);
            //hiện thị lại
            display();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //kiểm tra dữ liệu nhập
            if(txtTradeMarkName.Text.Trim() == "")
            {
                MessageBox.Show("Nhập tên thương hiệu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTradeMarkName.Focus();
                return;
            }
            //kiểm tra trùng TradeMarkName
            if((modNew == true) || (modNew == false) && (txtTradeMarkName.Text.Trim() != oldTradeMarkName.Trim()))
            {
                string sSql = "SELECT TradeMarkName FROM TradeMark WHERE TradeMarkName = N'" + txtTradeMarkName.Text + "'";
                DataServices myDataservies = new DataServices();
                DataTable dtSearch = myDataservies.RunQuery(sSql);
                if(dtSearch.Rows.Count > 0)
                {
                    MessageBox.Show("Đã nhập/sửa trùng tên thương hiệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTradeMarkName.Focus();
                    return;
                }

                if(modNew == true)
                {
                    //thêm dữ liệu
                    string ssSql = "INSERT INTO TradeMark(TradeMarkName,Description) VALUES (N'" + txtTradeMarkName.Text + "',N'" + txtDescription.Text + "')";
                    myDataServies.ExecuteNonQuery(ssSql);
                }
                else
                {
                    //sửa dữ liệu
                    //lấy dòng cần sửa
                    int r = dgvTradeMark.CurrentRow.Index;
                    //Lấy mã ID cần sửa
                    string TradeMarkID = dgvTradeMark.Rows[r].Cells[0].Value.ToString();
                    //Lệnh sửa
                    string ssSql = "UPDATE TradeMark SET TradeMarkName = N'" + txtTradeMarkName.Text + "',Description = N'" + txtDescription.Text + "' WHERE TradeMarkID = '" + TradeMarkID + "'";
                    myDataServies.ExecuteNonQuery(ssSql);
                }
                display();

                SetControl(false);
            }    
        }
    }
}
