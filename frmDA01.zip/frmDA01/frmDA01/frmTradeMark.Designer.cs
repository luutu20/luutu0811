﻿namespace frmDA01
{
    partial class frmTradeMark
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.lbTradeMarkName = new System.Windows.Forms.Label();
            this.lbDescription = new System.Windows.Forms.Label();
            this.txtTradeMarkName = new System.Windows.Forms.TextBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.tradeMarkBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dgvTradeMark = new System.Windows.Forms.DataGridView();
            this.TradeMarkID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TradeMarkName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.tradeMarkBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTradeMark)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(229, 213);
            this.btnClose.Margin = new System.Windows.Forms.Padding(2);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(72, 36);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "Thoát";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(229, 158);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(72, 36);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "Xóa";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(29, 213);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(72, 36);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Ghi";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(29, 158);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(72, 36);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(125, 213);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(72, 36);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(125, 158);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(2);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(72, 36);
            this.btnEdit.TabIndex = 3;
            this.btnEdit.Text = "Sửa";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // lbTradeMarkName
            // 
            this.lbTradeMarkName.AutoSize = true;
            this.lbTradeMarkName.Location = new System.Drawing.Point(30, 30);
            this.lbTradeMarkName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbTradeMarkName.Name = "lbTradeMarkName";
            this.lbTradeMarkName.Size = new System.Drawing.Size(111, 15);
            this.lbTradeMarkName.TabIndex = 114;
            this.lbTradeMarkName.Text = "Tên Thương hiệu(*):";
            // 
            // lbDescription
            // 
            this.lbDescription.AutoSize = true;
            this.lbDescription.Location = new System.Drawing.Point(30, 66);
            this.lbDescription.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbDescription.Name = "lbDescription";
            this.lbDescription.Size = new System.Drawing.Size(41, 15);
            this.lbDescription.TabIndex = 115;
            this.lbDescription.Text = "Mô tả:";
            // 
            // txtTradeMarkName
            // 
            this.txtTradeMarkName.Location = new System.Drawing.Point(147, 27);
            this.txtTradeMarkName.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtTradeMarkName.Name = "txtTradeMarkName";
            this.txtTradeMarkName.Size = new System.Drawing.Size(190, 23);
            this.txtTradeMarkName.TabIndex = 0;
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(147, 62);
            this.txtDescription.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(190, 23);
            this.txtDescription.TabIndex = 1;
            // 
            // dgvTradeMark
            // 
            this.dgvTradeMark.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTradeMark.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TradeMarkID,
            this.TradeMarkName,
            this.Description});
            this.dgvTradeMark.Location = new System.Drawing.Point(369, 27);
            this.dgvTradeMark.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dgvTradeMark.Name = "dgvTradeMark";
            this.dgvTradeMark.Size = new System.Drawing.Size(443, 223);
            this.dgvTradeMark.TabIndex = 116;
            this.dgvTradeMark.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTradeMark_RowEnter);
            // 
            // TradeMarkID
            // 
            this.TradeMarkID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.TradeMarkID.DataPropertyName = "TradeMarkID";
            this.TradeMarkID.HeaderText = "TradeMarkID";
            this.TradeMarkID.Name = "TradeMarkID";
            // 
            // TradeMarkName
            // 
            this.TradeMarkName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.TradeMarkName.DataPropertyName = "TradeMarkName";
            this.TradeMarkName.HeaderText = "Tên Thương hiệu";
            this.TradeMarkName.Name = "TradeMarkName";
            // 
            // Description
            // 
            this.Description.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Description.DataPropertyName = "Description";
            this.Description.HeaderText = "Mô tả";
            this.Description.Name = "Description";
            // 
            // frmTradeMark
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(847, 287);
            this.Controls.Add(this.dgvTradeMark);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.txtTradeMarkName);
            this.Controls.Add(this.lbDescription);
            this.Controls.Add(this.lbTradeMarkName);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnEdit);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "frmTradeMark";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmTradeMark";
            this.Load += new System.EventHandler(this.frmTradeMark_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tradeMarkBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTradeMark)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Label lbTradeMarkName;
        private System.Windows.Forms.Label lbDescription;
        private System.Windows.Forms.TextBox txtTradeMarkName;
        private System.Windows.Forms.TextBox txtDescription;
        
        private System.Windows.Forms.BindingSource tradeMarkBindingSource;
        
        private System.Windows.Forms.DataGridView dgvTradeMark;
        private System.Windows.Forms.DataGridViewTextBoxColumn TradeMarkID;
        private System.Windows.Forms.DataGridViewTextBoxColumn TradeMarkName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
    }
}