﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmDA01
{
    public partial class frmSuppliers : Form
    {
        private DataServices supDataservices = new DataServices();
        private DataTable dtSuppliers;
        private bool modeNew;
        private string oldSuppliers, oldPhone;
        public frmSuppliers()
        {
            InitializeComponent();
        }

        private void frmSuppliers_Load(object sender, EventArgs e)
        {
            supDataservices.OpenDB();

            disPlay();
            setControl(false);
        }

        private void disPlay()
        {
            string sSql = "SELECT * FROM Suppliers ORDER BY SupplierName";
            dtSuppliers = supDataservices.RunQuery(sSql);
            dgvSuppliers.DataSource = dtSuppliers;
        }

        private void setControl(bool edit)
        {
            txtSupplierName.Enabled = edit;
            txtContactName.Enabled = edit;
            txtAddress.Enabled = edit;
            txtPhone.Enabled = edit;
            txtEmail.Enabled = edit;
            txtDescription.Enabled = edit;

            btnAdd.Enabled = !edit;
            btnEdit.Enabled = !edit;
            btnSave.Enabled = edit;
            btnCancel.Enabled = edit;
            btnDelete.Enabled = !edit;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            modeNew = true;
            txtSupplierName.Clear();
            txtAddress.Clear();
            txtEmail.Clear();
            txtPhone.Clear();
            txtDescription.Clear();
            txtContactName.Clear();
            setControl(true);

            txtSupplierName.Focus();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            modeNew = false;
            setControl(true);
            txtSupplierName.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            setControl(false);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //1. hỏi xác nhận xóa dữ liệu không?
            DialogResult dr;
            dr = MessageBox.Show("Chắc chắn xóa dòng đang chọn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No) return;

            //2. lấy dòng con trỏ đang chọn trên lưới -> dòng cần xóa
            int r = dgvSuppliers.CurrentRow.Index;

            //3. xóa dòng r trong dtSuppliers
            dtSuppliers.Rows[r].Delete();

            //4. cập nhật lại dtSuppliers vào bảng Suppliers
            supDataservices.Update(dtSuppliers);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //kiểm tra dữ liệu
            if (txtSupplierName.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập tên nhà cung cấp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSupplierName.Focus();
                return;
            }
            if (txtContactName.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập người liên hệ của nhà cung cấp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtContactName.Focus();
                return;
            }
            if (txtPhone.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập số điện thoại của nhà cung cấp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtPhone.Focus();
                return;
            }
            if (txtAddress.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập địa chỉ của nhà cung cấp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtAddress.Focus();
                return;
            }
            if (txtEmail.Text.Trim() == "")
            {
                MessageBox.Show("Đề nghị nhập Email của nhà cung cấp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtEmail.Focus();
                return;
            }
            //kiểm tra trùng tên nhà cung cấp
            if ((modeNew == true) || ((modeNew == false) && (txtSupplierName.Text.Trim() != oldSuppliers.Trim())))
            {
                string sSql = "SELECT SupplierID FROM Suppliers WHERE SupplierName = N'" + txtSupplierName.Text + "'";
                DataServices myDataService1 = new DataServices();
                DataTable dtSearch = myDataService1.RunQuery(sSql);
                if (dtSearch.Rows.Count > 0)
                {
                    MessageBox.Show("Đã nhập trùng tên nhà cung cấp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtSupplierName.Focus();
                    return;
                }
            }
            //kiểm tra trùng số Phone
            if ((modeNew == true) || ((modeNew == false) && (txtPhone.Text.Trim() != oldPhone.Trim())))
            {
                string sSql = "SELECT SupplierID FROM Suppliers WHERE Phone = N'" + txtPhone.Text + "'";
                DataServices myDataService1 = new DataServices();
                DataTable dtSearch = myDataService1.RunQuery(sSql);
                if (dtSearch.Rows.Count > 0)
                {
                    MessageBox.Show("Đã nhập trùng số điện thoại của nhà cung cấp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtPhone.Focus();
                    return;
                }
            }
            
            //thêm mới hoặc sửa
            if (modeNew == true)
            {
                //thêm mới dữ liệu
                //1. tạo 1 dòng có cấu trúc như dtSuppliers
                DataRow addRow = dtSuppliers.NewRow();
                addRow["SupplierName"] = txtSupplierName.Text;
                addRow["ContactName"] = txtContactName.Text;
                addRow["Address"] = txtAddress.Text;
                addRow["Phone"] = txtPhone.Text;
                addRow["Email"] = txtEmail.Text;
                addRow["Description"] = txtDescription.Text;
                //2. thêm dòng vừa tạo vào dtSuppliers
                dtSuppliers.Rows.Add(addRow);
                //3. cập nhật dtSuppliers vào bảng dữ liệu Suppliers
                supDataservices.Update(dtSuppliers);
            }
            else
            {
                //sửa dữ liệu
                //1. lấy dòng cần sửa
                int r = dgvSuppliers.CurrentRow.Index;
                //2. lấy dòng r trong dtSuppliers
                DataRow editRow = dtSuppliers.Rows[r];
                editRow["SupplierName"] = txtSupplierName.Text;
                editRow["ContactName"] = txtContactName.Text;
                editRow["Address"] = txtAddress.Text;
                editRow["Phone"] = txtPhone.Text;
                editRow["Email"] = txtEmail.Text;
                editRow["Description"] = txtDescription.Text;
                //3. Cập nhật dtSuppliers vào bảng dữ liệu Suppliers
                supDataservices.Update(dtSuppliers);
            }
            disPlay();
            setControl(false);
        }

        private void dgvSuppliers_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtSupplierName.Text = dgvSuppliers.Rows[e.RowIndex].Cells["SupplierName"].Value.ToString();
            txtContactName.Text = dgvSuppliers.Rows[e.RowIndex].Cells["ContactName"].Value.ToString();
            txtAddress.Text = dgvSuppliers.Rows[e.RowIndex].Cells["Address"].Value.ToString();
            txtPhone.Text = dgvSuppliers.Rows[e.RowIndex].Cells["Phone"].Value.ToString();
            txtEmail.Text = dgvSuppliers.Rows[e.RowIndex].Cells["Email"].Value.ToString();
            txtDescription.Text = dgvSuppliers.Rows[e.RowIndex].Cells["Description"].Value.ToString();

            oldSuppliers = txtSupplierName.Text;
            oldPhone = txtPhone.Text;
        }

        private void tbPhone_CheckedChanged(object sender, EventArgs e)
        {
            rbSupplierName.Enabled = false;
            txtSearch.Focus();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (rbSupplierName.Checked == true)
            {
                string sSql = "SELECT * FROM Suppliers WHERE SupplierName LIKE N'%" + txtSearch.Text + "%'";
                DataTable dtSearch = supDataservices.RunQuery(sSql);
                dgvSuppliers.DataSource = dtSearch;

            }
            else
            {
                string sSql = "SELECT * FROM Suppliers WHERE Phone LIKE '%" + txtSearch.Text + "%'";
                DataTable dtSearch = supDataservices.RunQuery(sSql);
                dgvSuppliers.DataSource = dtSearch;
            }
            txtSearch.Clear();
            rbSupplierName.Enabled = true;
            tbPhone.Enabled = true;
            rbSupplierName.Checked = false;
            tbPhone.Checked = false;
        }

        private void rbSupplierName_CheckedChanged_1(object sender, EventArgs e)
        {
            tbPhone.Enabled = false;
            txtSearch.Focus();
        }
    }
}
